import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./components/AuthContext";
import Index from "./pages/Index";
import Game from "./pages/Game";
import LogicChamber from "./pages/LogicChamber";
import PatternVault from "./pages/PatternVault";
import MemoryCore from "./pages/MemoryCore";
import SpeedZone from "./pages/SpeedZone";
import CreativityChamber from "./pages/CreativityChamber";
import SpatialLab from "./pages/SpatialLab";
import Results from "./pages/Results";
import Review from "./pages/Review";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Profile from "./pages/Profile";
import Leaderboard from "./pages/Leaderboard";
import About from "./pages/About";
import Placeholder from "./pages/Placeholder";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/game" element={<Game />} />
              <Route path="/game/logic" element={<LogicChamber />} />
              <Route path="/game/pattern" element={<PatternVault />} />
              <Route path="/game/memory" element={<MemoryCore />} />
              <Route path="/game/speed" element={<SpeedZone />} />
              <Route path="/game/creativity" element={<CreativityChamber />} />
              <Route path="/game/spatial" element={<SpatialLab />} />
              <Route path="/results" element={<Results />} />
              <Route path="/review" element={<Review />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/leaderboard" element={<Leaderboard />} />
              <Route path="/about" element={<About />} />
              <Route
                path="/demo"
                element={
                  <Placeholder
                    title="Demo Mode"
                    description="Try a sample puzzle before starting the full assessment"
                  />
                }
              />
              <Route
                path="/terms"
                element={
                  <Placeholder
                    title="Terms of Service"
                    description="Mind Lab terms and conditions"
                  />
                }
              />
              <Route
              path="/privacy"
              element={
                <Placeholder
                  title="Privacy Policy"
                  description="How we protect your data and privacy"
                />
              }
            />
            <Route
              path="/forgot-password"
              element={
                <Placeholder
                  title="Forgot Password"
                  description="Password recovery will be available soon"
                />
              }
            />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}
