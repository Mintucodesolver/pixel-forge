import React from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import {
  Brain,
  Target,
  Zap,
  Clock,
  Users,
  Shield,
  Award,
  Microscope,
  ChevronRight,
  CheckCircle,
  TrendingUp,
  BookOpen,
  Lightbulb,
  Star,
  Globe,
  Lock,
  Mail,
  ArrowLeft,
  Box,
} from "lucide-react";
import Header from "../components/Header";

export default function About() {
  const teamMembers = [
    {
      name: "Dr. Sarah Chen",
      role: "Chief Cognitive Scientist",
      expertise: "Psychometrics & Neural Networks",
      image: "🧠",
      bio: "PhD in Cognitive Psychology from MIT. 15+ years developing advanced IQ assessment methodologies.",
    },
    {
      name: "Marcus Rodriguez",
      role: "Head of Platform Engineering",
      expertise: "AI & Machine Learning",
      image: "⚡",
      bio: "Former Google engineer specializing in adaptive testing algorithms and real-time performance analytics.",
    },
    {
      name: "Dr. Elena Volkov",
      role: "Director of Research",
      expertise: "Behavioral Analytics",
      image: "🎯",
      bio: "Leading researcher in cognitive assessment with 20+ published papers on intelligence measurement.",
    },
  ];

  const features = [
    {
      icon: Brain,
      title: "Advanced Psychometrics",
      description:
        "Our algorithms are based on decades of cognitive science research and validated testing methodologies.",
    },
    {
      icon: Target,
      title: "Adaptive Testing",
      description:
        "Dynamic difficulty adjustment ensures optimal challenge levels for accurate IQ measurement.",
    },
    {
      icon: TrendingUp,
      title: "Real-time Analytics",
      description:
        "Instant feedback and detailed performance metrics help you understand your cognitive strengths.",
    },
    {
      icon: Shield,
      title: "Privacy First",
      description:
        "Your data is encrypted and secure. We never share personal information with third parties.",
    },
  ];

  const methodology = [
    {
      step: "1",
      title: "Multi-Domain Assessment",
      description:
        "Test across 4 key cognitive areas: logic, pattern recognition, memory, and processing speed.",
      icon: Microscope,
    },
    {
      step: "2",
      title: "Adaptive Difficulty",
      description:
        "Our AI adjusts question difficulty in real-time based on your performance for optimal accuracy.",
      icon: TrendingUp,
    },
    {
      step: "3",
      title: "Comprehensive Analysis",
      description:
        "Generate detailed reports showing strengths, weaknesses, and personalized improvement recommendations.",
      icon: BookOpen,
    },
    {
      step: "4",
      title: "Continuous Learning",
      description:
        "Track progress over time with our advanced analytics and performance tracking systems.",
      icon: Lightbulb,
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="absolute inset-0 grid-pattern opacity-20" />

      <div className="relative container mx-auto px-4 py-8">
        <Header showProgress={false} showAuth={true} />

        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-secondary/50 px-4 py-2 rounded-full mb-6 glass-effect">
            <BookOpen className="w-4 h-4 text-neon-cyan" />
            <span className="text-sm text-muted-foreground">
              Learn About Mind Lab
            </span>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-neon-cyan via-neon-purple to-neon-green bg-clip-text text-transparent">
            About Mind Lab
          </h1>

          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            The future of cognitive assessment. Discover how we're
            revolutionizing IQ testing with cutting-edge technology and
            scientific rigor.
          </p>
        </div>

        {/* Mission Section */}
        <Card className="glass-effect border-border/50 mb-16">
          <CardContent className="p-12">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold mb-6 text-neon-cyan">
                  Our Mission
                </h2>
                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                  Mind Lab is dedicated to making cognitive assessment
                  accessible, accurate, and engaging. We believe everyone
                  deserves to understand their intellectual potential and
                  cognitive strengths.
                </p>
                <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                  Our platform combines the latest advances in psychometrics,
                  artificial intelligence, and user experience design to create
                  the most comprehensive IQ testing experience available.
                </p>
                <div className="flex gap-4">
                  <Button asChild className="animate-pulse-glow">
                    <Link to="/game">
                      Start Testing
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Link>
                  </Button>
                  <Button variant="outline" asChild>
                    <Link to="/demo">Try Demo</Link>
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="text-center bg-secondary/10 rounded-lg p-6">
                  <div className="text-3xl font-bold text-neon-cyan mb-2">
                    500K+
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Tests Completed
                  </div>
                </div>
                <div className="text-center bg-secondary/10 rounded-lg p-6">
                  <div className="text-3xl font-bold text-neon-purple mb-2">
                    98.5%
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Accuracy Rate
                  </div>
                </div>
                <div className="text-center bg-secondary/10 rounded-lg p-6">
                  <div className="text-3xl font-bold text-neon-green mb-2">
                    120+
                  </div>
                  <div className="text-sm text-muted-foreground">Countries</div>
                </div>
                <div className="text-center bg-secondary/10 rounded-lg p-6">
                  <div className="text-3xl font-bold text-neon-orange mb-2">
                    4.2★
                  </div>
                  <div className="text-sm text-muted-foreground">
                    User Rating
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* How It Works */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 text-foreground">
              How Mind Lab Works
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our scientifically-validated methodology ensures accurate and
              reliable IQ assessment
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {methodology.map((item, index) => {
              const Icon = item.icon;
              return (
                <Card
                  key={index}
                  className="glass-effect border-border/50 relative overflow-hidden"
                >
                  <div className="absolute top-4 right-4 w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold text-primary">
                      {item.step}
                    </span>
                  </div>
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-neon-cyan/20 rounded-lg flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 text-neon-cyan" />
                    </div>
                    <h3 className="font-semibold mb-3">{item.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {item.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Testing Chambers */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 text-foreground">
              Our Testing Chambers
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Each chamber targets specific cognitive abilities for
              comprehensive assessment
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="glass-effect border-neon-cyan/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-neon-cyan/20 rounded-lg flex items-center justify-center">
                    <Brain className="w-5 h-5 text-neon-cyan" />
                  </div>
                  Logic Chamber
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Tests analytical reasoning, problem-solving, and deductive
                  logic through progressive challenges.
                </p>
                <div className="flex gap-2 flex-wrap">
                  <Badge variant="outline">Reasoning</Badge>
                  <Badge variant="outline">Problem Solving</Badge>
                  <Badge variant="outline">Deduction</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-effect border-neon-purple/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-neon-purple/20 rounded-lg flex items-center justify-center">
                    <Target className="w-5 h-5 text-neon-purple" />
                  </div>
                  Pattern Vault
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Evaluates pattern recognition, sequence analysis, and
                  visual-spatial intelligence.
                </p>
                <div className="flex gap-2 flex-wrap">
                  <Badge variant="outline">Pattern Recognition</Badge>
                  <Badge variant="outline">Visual-Spatial</Badge>
                  <Badge variant="outline">Sequences</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-effect border-neon-green/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-neon-green/20 rounded-lg flex items-center justify-center">
                    <Brain className="w-5 h-5 text-neon-green" />
                  </div>
                  Memory Core
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Measures working memory, recall ability, and information
                  processing capacity.
                </p>
                <div className="flex gap-2 flex-wrap">
                  <Badge variant="outline">Working Memory</Badge>
                  <Badge variant="outline">Recall</Badge>
                  <Badge variant="outline">Processing</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-effect border-neon-orange/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-neon-orange/20 rounded-lg flex items-center justify-center">
                    <Zap className="w-5 h-5 text-neon-orange" />
                  </div>
                  Speed Zone
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Assesses cognitive processing speed and performance under time
                  pressure.
                </p>
                <div className="flex gap-2 flex-wrap">
                  <Badge variant="outline">Processing Speed</Badge>
                  <Badge variant="outline">Time Pressure</Badge>
                  <Badge variant="outline">Quick Thinking</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-effect border-pink-500/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-pink-500/20 rounded-lg flex items-center justify-center">
                    <Lightbulb className="w-5 h-5 text-pink-500" />
                  </div>
                  Creativity Chamber
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Tests creative thinking, lateral problem-solving, and
                  innovative reasoning abilities.
                </p>
                <div className="flex gap-2 flex-wrap">
                  <Badge variant="outline">Creative Thinking</Badge>
                  <Badge variant="outline">Lateral Logic</Badge>
                  <Badge variant="outline">Innovation</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-effect border-teal-500/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-teal-500/20 rounded-lg flex items-center justify-center">
                    <Box className="w-5 h-5 text-teal-500" />
                  </div>
                  Spatial Lab
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Evaluates 3D spatial reasoning, mental rotation, and
                  dimensional visualization skills.
                </p>
                <div className="flex gap-2 flex-wrap">
                  <Badge variant="outline">3D Reasoning</Badge>
                  <Badge variant="outline">Mental Rotation</Badge>
                  <Badge variant="outline">Spatial Intelligence</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Key Features */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 text-foreground">
              Why Choose Mind Lab?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Advanced technology meets scientific rigor for the most accurate
              IQ assessment
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card
                  key={index}
                  className="glass-effect border-border/50 hover:border-neon-cyan/30 transition-all duration-300"
                >
                  <CardContent className="p-8">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-neon-cyan/20 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6 text-neon-cyan" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg mb-3">
                          {feature.title}
                        </h3>
                        <p className="text-muted-foreground leading-relaxed">
                          {feature.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Team Section */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 text-foreground">
              Meet Our Team
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              World-class experts in cognitive science, AI, and user experience
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {teamMembers.map((member, index) => (
              <Card
                key={index}
                className="glass-effect border-border/50 hover:border-neon-purple/30 transition-all duration-300"
              >
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-neon-cyan to-neon-purple rounded-full flex items-center justify-center mx-auto mb-4 text-3xl">
                    {member.image}
                  </div>
                  <h3 className="font-semibold text-lg mb-1">{member.name}</h3>
                  <p className="text-neon-purple font-medium mb-2">
                    {member.role}
                  </p>
                  <Badge variant="outline" className="mb-4">
                    {member.expertise}
                  </Badge>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {member.bio}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Security & Privacy */}
        <Card className="glass-effect border-border/50 mb-16">
          <CardContent className="p-12">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold mb-6 flex items-center gap-3">
                  <Shield className="w-8 h-8 text-neon-green" />
                  Security & Privacy
                </h2>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-neon-green mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold mb-1">
                        End-to-End Encryption
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        All data is encrypted in transit and at rest using
                        AES-256 encryption
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-neon-green mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold mb-1">GDPR Compliant</h4>
                      <p className="text-sm text-muted-foreground">
                        Full compliance with international privacy regulations
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-neon-green mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold mb-1">No Data Selling</h4>
                      <p className="text-sm text-muted-foreground">
                        We never sell or share your personal data with third
                        parties
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-neon-green mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold mb-1">
                        Secure Infrastructure
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        Hosted on enterprise-grade cloud infrastructure with
                        99.9% uptime
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-secondary/5 rounded-lg p-8 text-center">
                <Lock className="w-16 h-16 text-neon-green mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">
                  Your Data is Safe
                </h3>
                <p className="text-sm text-muted-foreground mb-6">
                  We use industry-leading security practices to protect your
                  information and test results.
                </p>
                <Button variant="outline" className="glass-effect">
                  <Shield className="w-4 h-4 mr-2" />
                  View Privacy Policy
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA Section */}
        <div className="text-center mb-16">
          <Card className="glass-effect border-neon-cyan/30 bg-gradient-to-r from-neon-cyan/5 to-neon-purple/5">
            <CardContent className="p-12">
              <h2 className="text-3xl font-bold mb-4">
                Ready to Discover Your IQ?
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Join hundreds of thousands of users who have unlocked their
                cognitive potential with Mind Lab.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg" className="animate-pulse-glow">
                  <Link to="/game">
                    Start Your IQ Test
                    <ChevronRight className="w-5 h-5 ml-2" />
                  </Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <Link to="/signup">Create Free Account</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Contact Section */}
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="glass-effect border-border/50">
            <CardContent className="p-6 text-center">
              <Mail className="w-8 h-8 text-neon-cyan mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Contact Us</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Get in touch with our team
              </p>
              <p className="text-sm text-neon-cyan">hello@mindlab.ai</p>
            </CardContent>
          </Card>

          <Card className="glass-effect border-border/50">
            <CardContent className="p-6 text-center">
              <Users className="w-8 h-8 text-neon-purple mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Community</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Join our global community
              </p>
              <Link
                to="/leaderboard"
                className="text-sm text-neon-purple hover:underline"
              >
                View Leaderboard
              </Link>
            </CardContent>
          </Card>

          <Card className="glass-effect border-border/50">
            <CardContent className="p-6 text-center">
              <Globe className="w-8 h-8 text-neon-green mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Global Reach</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Available worldwide
              </p>
              <p className="text-sm text-neon-green">120+ Countries</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
