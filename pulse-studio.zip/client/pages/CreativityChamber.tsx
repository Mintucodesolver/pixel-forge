import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Progress } from "../components/ui/progress";
import {
  Lightbulb,
  ArrowLeft,
  Clock,
  Zap,
  CheckCircle,
  XCircle,
  Sparkles,
} from "lucide-react";

interface Puzzle {
  id: number;
  question: string;
  type: "lateral" | "creative" | "analogy" | "alternative";
  options: string[];
  correct: number;
  difficulty: "easy" | "medium" | "hard" | "expert";
  timeLimit: number;
  points: number;
  hint?: string;
}

const puzzles: Puzzle[] = [
  {
    id: 1,
    question:
      "A man lives on the 30th floor. When it rains, he takes the elevator to the top. When it's sunny, he gets off at the 20th floor and walks. Why?",
    type: "lateral",
    options: [
      "He's afraid of heights when sunny",
      "He's too short to reach the 30th button without an umbrella",
      "He likes exercise on sunny days",
      "The elevator is broken when sunny",
    ],
    correct: 1,
    difficulty: "easy",
    timeLimit: 90,
    points: 8,
    hint: "Think about what he might carry when it rains...",
  },
  {
    id: 2,
    question: "What can you use a brick for besides building?",
    type: "creative",
    options: [
      "Doorstop, paperweight, exercise weight",
      "Only building purposes",
      "Decoration only",
      "Breaking things only",
    ],
    correct: 0,
    difficulty: "easy",
    timeLimit: 60,
    points: 6,
  },
  {
    id: 3,
    question: "BOOK is to READING as FORK is to:",
    type: "analogy",
    options: ["KITCHEN", "EATING", "METAL", "DINNER"],
    correct: 1,
    difficulty: "easy",
    timeLimit: 45,
    points: 5,
  },
  {
    id: 4,
    question:
      "A man says 'I have no brothers or sisters, but that man's father is my father's son.' Who is 'that man'?",
    type: "lateral",
    options: ["His cousin", "His son", "His nephew", "Himself"],
    correct: 1,
    difficulty: "medium",
    timeLimit: 90,
    points: 10,
  },
  {
    id: 5,
    question: "How many uses can you think of for a paperclip?",
    type: "creative",
    options: ["1-3 uses", "4-7 uses", "8-12 uses", "13+ uses"],
    correct: 3,
    difficulty: "medium",
    timeLimit: 120,
    points: 12,
  },
  {
    id: 6,
    question: "OCEAN is to WAVE as DESERT is to:",
    type: "analogy",
    options: ["SAND", "DUNE", "HOT", "CAMEL"],
    correct: 1,
    difficulty: "medium",
    timeLimit: 60,
    points: 8,
  },
  {
    id: 7,
    question:
      "Two girls were born to the same mother, at the same time, on the same day, but they're not twins. How?",
    type: "lateral",
    options: [
      "They're adopted",
      "They're triplets (or more)",
      "One was born first",
      "They're step-sisters",
    ],
    correct: 1,
    difficulty: "medium",
    timeLimit: 100,
    points: 12,
  },
  {
    id: 8,
    question:
      "If you could redesign the human hand, what would you change and why?",
    type: "creative",
    options: [
      "Add more fingers for dexterity",
      "Make it waterproof and stronger",
      "Add tool attachments",
      "All creative solutions are valid",
    ],
    correct: 3,
    difficulty: "hard",
    timeLimit: 150,
    points: 15,
  },
  {
    id: 9,
    question: "SILENCE is to NOISE as DARKNESS is to:",
    type: "analogy",
    options: ["BLINDNESS", "LIGHT", "SHADOW", "VISION"],
    correct: 1,
    difficulty: "hard",
    timeLimit: 75,
    points: 12,
  },
  {
    id: 10,
    question:
      "A man pushed his car to a hotel and lost his fortune. What happened?",
    type: "lateral",
    options: [
      "Car accident at hotel",
      "Playing Monopoly",
      "Valet parking fee",
      "Hotel parking was expensive",
    ],
    correct: 1,
    difficulty: "hard",
    timeLimit: 120,
    points: 18,
  },
  {
    id: 11,
    question:
      "Design a solution for people who forget their keys. Think outside the box.",
    type: "creative",
    options: [
      "Biometric locks only",
      "Smartphone integration",
      "Multiple creative solutions",
      "Traditional spare key",
    ],
    correct: 2,
    difficulty: "hard",
    timeLimit: 180,
    points: 20,
  },
  {
    id: 12,
    question: "What comes next in this creative sequence: Paint, Canvas, ?",
    type: "alternative",
    options: ["Brush", "Masterpiece", "Gallery", "Artist"],
    correct: 1,
    difficulty: "expert",
    timeLimit: 90,
    points: 15,
  },
  {
    id: 13,
    question:
      "A woman shoots her husband, holds him underwater for 5 minutes, then hangs him. Later they go out for dinner. How?",
    type: "lateral",
    options: [
      "She's a doctor saving him",
      "She's developing photographs",
      "He's unconscious",
      "They're acting",
    ],
    correct: 1,
    difficulty: "expert",
    timeLimit: 150,
    points: 25,
  },
  {
    id: 14,
    question:
      "Combine a refrigerator and a bicycle. What innovative product would you create?",
    type: "creative",
    options: [
      "Mobile food cart",
      "Exercise-powered cooling",
      "Portable cooling device",
      "All solutions show creativity",
    ],
    correct: 3,
    difficulty: "expert",
    timeLimit: 200,
    points: 30,
  },
  {
    id: 15,
    question: "BEGINNING is to END as QUESTION is to:",
    type: "analogy",
    options: ["ANSWER", "PERIOD", "UNKNOWN", "THOUGHT"],
    correct: 0,
    difficulty: "expert",
    timeLimit: 60,
    points: 18,
  },
];

export default function CreativityChamber() {
  const navigate = useNavigate();
  const [currentPuzzle, setCurrentPuzzle] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(puzzles[0]?.timeLimit || 60);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [gameStarted, setGameStarted] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [creativityBonus, setCreativityBonus] = useState(0);

  const puzzle = puzzles[currentPuzzle] || puzzles[0];
  const progress =
    puzzles.length > 0
      ? ((currentPuzzle + (showResult ? 1 : 0)) / puzzles.length) * 100
      : 0;

  useEffect(() => {
    if (!gameStarted) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentPuzzle, gameStarted]);

  const handleTimeUp = () => {
    setShowResult(true);
    setIsCorrect(false);
    setTimeout(() => nextPuzzle(), 2500);
  };

  const handleAnswer = (answerIndex: number) => {
    if (showResult) return;

    setSelectedAnswer(answerIndex);
    const currentPuzzleData = puzzles[currentPuzzle];
    if (!currentPuzzleData) return;

    const correct = answerIndex === currentPuzzleData.correct;

    setIsCorrect(correct);
    setShowResult(true);

    if (correct) {
      const timeBonus = Math.floor(
        (timeLeft / currentPuzzleData.timeLimit) * 10,
      );
      const creativityBonusPoints =
        currentPuzzleData.type === "creative" ? 5 : 0;
      const totalPoints =
        currentPuzzleData.points + timeBonus + creativityBonusPoints;

      setScore((prev) => prev + totalPoints);
      setCreativityBonus((prev) => prev + creativityBonusPoints);
    }

    setTimeout(() => nextPuzzle(), 2500);
  };

  const nextPuzzle = () => {
    if (currentPuzzle < puzzles.length - 1) {
      setCurrentPuzzle((prev) => prev + 1);
      setSelectedAnswer(null);
      setShowResult(false);
      setIsCorrect(null);
      setShowHint(false);
      const nextPuzzle = puzzles[currentPuzzle + 1];
      setTimeLeft(nextPuzzle?.timeLimit || 60);
    } else {
      navigate("/results", {
        state: {
          score,
          totalPossible: puzzles.reduce(
            (sum, p) => sum + (p?.points || 0) + 15,
            0,
          ),
          chamber: "Creativity Chamber",
          creativityBonus,
        },
      });
    }
  };

  const startGame = () => {
    setGameStarted(true);
    setTimeLeft(puzzles[0]?.timeLimit || 60);
  };

  const useHint = () => {
    if (puzzle?.hint && !showHint && !showResult) {
      setShowHint(true);
      setTimeLeft((prev) => Math.max(0, prev - 15)); // Penalty for using hint
    }
  };

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="absolute inset-0 grid-pattern opacity-20" />

        <Card className="max-w-2xl w-full mx-4 glass-effect border-pink-500/50">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-pink-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Lightbulb className="w-8 h-8 text-pink-500" />
            </div>
            <CardTitle className="text-2xl text-pink-500">
              Creativity Chamber
            </CardTitle>
            <p className="text-muted-foreground">
              Unleash your creative and lateral thinking
            </p>
          </CardHeader>

          <CardContent className="space-y-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-4">Challenge Details</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Creative Puzzles</div>
                  <div className="text-muted-foreground">
                    {puzzles.length} Challenges
                  </div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Difficulty</div>
                  <div className="text-muted-foreground">Innovative</div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Time Limits</div>
                  <div className="text-muted-foreground">60-200s each</div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Special Bonus</div>
                  <div className="text-muted-foreground">Creativity Points</div>
                </div>
              </div>
            </div>

            <div className="text-center bg-pink-500/10 border border-pink-500/20 rounded-lg p-4">
              <div className="flex items-center justify-center gap-2 text-pink-400 text-sm mb-2">
                <Sparkles className="w-4 h-4" />
                <span className="font-semibold">Creative Thinking Mode</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Think outside the box! Creative solutions earn bonus points.
                Some puzzles have hints available.
              </p>
            </div>

            <div className="flex gap-4">
              <Button variant="outline" asChild className="flex-1">
                <Link to="/game">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Lobby
                </Link>
              </Button>
              <Button
                onClick={startGame}
                className="flex-1 animate-pulse-glow bg-pink-500 hover:bg-pink-500/90"
              >
                Start Challenge
                <Zap className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="absolute inset-0 grid-pattern opacity-20" />

      <div className="relative container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-pink-500/20 rounded-lg flex items-center justify-center">
              <Lightbulb className="w-4 h-4 text-pink-500" />
            </div>
            <span className="text-lg font-bold text-pink-500">
              Creativity Chamber
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Score</div>
              <div className="text-lg font-bold text-pink-500">{score}</div>
            </div>
            {creativityBonus > 0 && (
              <div className="text-right">
                <div className="text-sm text-muted-foreground">Creativity</div>
                <div className="text-lg font-bold text-yellow-400">
                  +{creativityBonus}
                </div>
              </div>
            )}
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Time</div>
              <div
                className={`text-lg font-bold ${timeLeft <= 15 ? "text-destructive" : timeLeft <= 30 ? "text-yellow-400" : "text-pink-500"}`}
              >
                {timeLeft}s
              </div>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <div className="flex justify-between text-sm mb-2">
            <span>
              Challenge {currentPuzzle + 1} of {puzzles.length}
            </span>
            <span>{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="glass-effect border-border/50 mb-8">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2 py-1 rounded text-xs font-medium ${
                      (puzzle?.difficulty || "easy") === "easy"
                        ? "bg-green-500/20 text-green-400"
                        : (puzzle?.difficulty || "easy") === "medium"
                          ? "bg-yellow-500/20 text-yellow-400"
                          : (puzzle?.difficulty || "easy") === "hard"
                            ? "bg-orange-500/20 text-orange-400"
                            : "bg-red-500/20 text-red-400"
                    }`}
                  >
                    {(puzzle?.difficulty || "easy").toUpperCase()}
                  </span>
                  <span
                    className={`px-2 py-1 rounded text-xs font-medium ${
                      (puzzle?.type || "creative") === "creative"
                        ? "bg-pink-500/20 text-pink-400"
                        : (puzzle?.type || "creative") === "lateral"
                          ? "bg-purple-500/20 text-purple-400"
                          : (puzzle?.type || "creative") === "analogy"
                            ? "bg-blue-500/20 text-blue-400"
                            : "bg-teal-500/20 text-teal-400"
                    }`}
                  >
                    {(puzzle?.type || "creative").toUpperCase()}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {puzzle?.points || 0} pts
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {puzzle?.hint && !showHint && !showResult && (
                    <Button size="sm" variant="outline" onClick={useHint}>
                      <Lightbulb className="w-3 h-3 mr-1" />
                      Hint (-15s)
                    </Button>
                  )}
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">
                    {puzzle?.timeLimit || 60}s
                  </span>
                </div>
              </div>
              <CardTitle className="text-xl leading-relaxed">
                {puzzle?.question || "Loading..."}
              </CardTitle>

              {showHint && puzzle?.hint && (
                <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                  <div className="flex items-center gap-2 text-yellow-400 text-sm mb-1">
                    <Lightbulb className="w-4 h-4" />
                    <span className="font-semibold">Hint</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{puzzle.hint}</p>
                </div>
              )}
            </CardHeader>

            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(puzzle?.options || []).map((option, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className={`p-6 h-auto text-left justify-start transition-all duration-300 ${
                      showResult && index === (puzzle?.correct || 0)
                        ? "border-neon-green bg-neon-green/10 text-neon-green"
                        : showResult &&
                            selectedAnswer === index &&
                            index !== (puzzle?.correct || 0)
                          ? "border-destructive bg-destructive/10 text-destructive"
                          : selectedAnswer === index
                            ? "border-pink-500 bg-pink-500/10"
                            : "border-border hover:border-pink-500/50"
                    } ${showResult ? "cursor-default" : "cursor-pointer hover:scale-[1.02]"}`}
                    onClick={() => handleAnswer(index)}
                    disabled={showResult}
                  >
                    <div className="flex items-center gap-3">
                      <span className="flex items-center justify-center w-6 h-6 rounded-full bg-secondary text-sm font-medium">
                        {String.fromCharCode(65 + index)}
                      </span>
                      <span className="flex-1 text-sm leading-relaxed">
                        {option}
                      </span>
                      {showResult && index === (puzzle?.correct || 0) && (
                        <CheckCircle className="w-5 h-5 text-neon-green" />
                      )}
                      {showResult &&
                        selectedAnswer === index &&
                        index !== (puzzle?.correct || 0) && (
                          <XCircle className="w-5 h-5 text-destructive" />
                        )}
                    </div>
                  </Button>
                ))}
              </div>

              {showResult && (
                <div className="mt-6 text-center">
                  <div
                    className={`text-lg font-semibold ${isCorrect ? "text-neon-green" : "text-destructive"}`}
                  >
                    {isCorrect
                      ? puzzle?.type === "creative"
                        ? "Creative Genius!"
                        : "Brilliant Thinking!"
                      : "Think Different!"}
                  </div>
                  {isCorrect && (
                    <div className="text-sm text-muted-foreground mt-1">
                      +
                      {(puzzle?.points || 0) +
                        Math.floor(
                          (timeLeft / (puzzle?.timeLimit || 60)) * 10,
                        ) +
                        (puzzle?.type === "creative" ? 5 : 0)}{" "}
                      points
                      {puzzle?.type === "creative" && (
                        <span className="text-pink-400 ml-1">
                          (Creativity Bonus!)
                        </span>
                      )}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
