import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Construction, ArrowLeft, Brain } from 'lucide-react';

interface PlaceholderProps {
  title: string;
  description: string;
}

export default function Placeholder({ title, description }: PlaceholderProps) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="absolute inset-0 grid-pattern opacity-20" />
      
      <div className="relative container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center animate-pulse-glow">
              <Brain className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-neon-cyan neon-glow">Mind Lab</span>
          </div>
        </div>

        {/* Placeholder Content */}
        <div className="flex items-center justify-center min-h-[60vh]">
          <Card className="max-w-2xl w-full glass-effect border-border/50">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Construction className="w-8 h-8 text-muted-foreground" />
              </div>
              <CardTitle className="text-2xl">{title}</CardTitle>
              <p className="text-muted-foreground">{description}</p>
            </CardHeader>
            
            <CardContent className="text-center space-y-6">
              <p className="text-muted-foreground">
                This feature is under development. Continue exploring Mind Lab to discover more IQ challenges 
                and unlock your cognitive potential.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild>
                  <Link to="/game">
                    Explore Chambers
                  </Link>
                </Button>
                
                <Button variant="outline" asChild>
                  <Link to="/" className="flex items-center gap-2">
                    <ArrowLeft className="w-4 h-4" />
                    Back to Home
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
