import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Progress } from '../components/ui/progress';
import { 
  User, 
  Brain, 
  Trophy, 
  Target, 
  Zap, 
  Clock, 
  Star,
  Calendar,
  Settings,
  Mail,
  Shield,
  Bell,
  Palette,
  Download,
  Share2,
  Award,
  TrendingUp,
  BarChart3,
  Edit,
  Save,
  X
} from 'lucide-react';
import Header from '../components/Header';
import { useAuth } from '../components/AuthContext';

interface UserStats {
  totalGames: number;
  avgScore: number;
  avgIQ: number;
  bestStreak: number;
  timeSpent: number;
  favoriteRoom: string;
  achievements: Achievement[];
  weeklyProgress: number;
  monthlyGoal: number;
  levelProgress: number;
  currentLevel: number;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  earned: boolean;
  dateEarned?: string;
  progress?: number;
  maxProgress?: number;
}

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    name: user?.name || '',
    email: user?.email || ''
  });
  const [userStats, setUserStats] = useState<UserStats>({
    totalGames: 0,
    avgScore: 0,
    avgIQ: 0,
    bestStreak: 0,
    timeSpent: 0,
    favoriteRoom: 'Logic Chamber',
    achievements: [],
    weeklyProgress: 0,
    monthlyGoal: 100,
    levelProgress: 0,
    currentLevel: 1
  });

  const achievements: Achievement[] = [
    {
      id: 'first_steps',
      title: 'First Steps',
      description: 'Complete your first IQ test',
      icon: '🎯',
      earned: true,
      dateEarned: '2024-01-15'
    },
    {
      id: 'speed_demon',
      title: 'Speed Demon',
      description: 'Answer 10 questions in under 5 seconds each',
      icon: '⚡',
      earned: true,
      dateEarned: '2024-01-16'
    },
    {
      id: 'perfect_score',
      title: 'Perfect Score',
      description: 'Get 100% accuracy in any chamber',
      icon: '💯',
      earned: false,
      progress: 95,
      maxProgress: 100
    },
    {
      id: 'streak_master',
      title: 'Streak Master',
      description: 'Maintain a 10-game winning streak',
      icon: '🔥',
      earned: false,
      progress: 7,
      maxProgress: 10
    },
    {
      id: 'brain_elite',
      title: 'Brain Elite',
      description: 'Achieve an IQ score above 130',
      icon: '🧠',
      earned: false,
      progress: 125,
      maxProgress: 130
    },
    {
      id: 'all_chambers',
      title: 'Chamber Master',
      description: 'Complete all 4 testing chambers',
      icon: '🏆',
      earned: false,
      progress: 2,
      maxProgress: 4
    },
    {
      id: 'time_warrior',
      title: 'Time Warrior',
      description: 'Spend 10 hours in Mind Lab',
      icon: '⏰',
      earned: false,
      progress: 6.5,
      maxProgress: 10
    },
    {
      id: 'social_sharer',
      title: 'Social Sharer',
      description: 'Share your results 5 times',
      icon: '📱',
      earned: false,
      progress: 2,
      maxProgress: 5
    }
  ];

  useEffect(() => {
    if (user) {
      const totalGames = Math.max(0, user.totalGamesPlayed || 0);
      const avgIQ = Math.max(85, Math.min(160, user.avgIQ || Math.floor(Math.random() * 20) + 105));

      setUserStats({
        totalGames,
        avgScore: Math.max(0, Math.floor(Math.random() * 50) + 70),
        avgIQ,
        bestStreak: Math.max(0, Math.floor(Math.random() * 15) + 5),
        timeSpent: Math.max(0, Math.floor(Math.random() * 20) + 5),
        favoriteRoom: 'Logic Chamber',
        achievements,
        weeklyProgress: Math.max(0, Math.min(100, Math.floor(Math.random() * 100))),
        monthlyGoal: 100,
        levelProgress: Math.max(0, Math.min(100, Math.floor(Math.random() * 100))),
        currentLevel: Math.max(1, Math.floor(totalGames / 10) + 1)
      });
      
      setEditForm({
        name: user?.name || '',
        email: user?.email || ''
      });
    }
  }, [user]);

  const handleSaveProfile = () => {
    if (user) {
      updateUser({
        name: editForm.name,
        email: editForm.email
      });
    }
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    setEditForm({
      name: user?.name || '',
      email: user?.email || ''
    });
    setIsEditing(false);
  };

  const getRoomIcon = (room: string) => {
    switch (room) {
      case 'Logic Chamber':
        return <Brain className="w-4 h-4 text-neon-cyan" />;
      case 'Pattern Vault':
        return <Target className="w-4 h-4 text-neon-purple" />;
      case 'Memory Core':
        return <Brain className="w-4 h-4 text-neon-green" />;
      case 'Speed Zone':
        return <Zap className="w-4 h-4 text-neon-orange" />;
      default:
        return <Brain className="w-4 h-4" />;
    }
  };

  const getNextLevel = () => {
    return Math.max(10, (userStats.currentLevel || 1) * 10);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <Card className="max-w-md w-full glass-effect border-border/50">
          <CardContent className="p-8 text-center">
            <User className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <h2 className="text-2xl font-bold mb-4">Login Required</h2>
            <p className="text-muted-foreground mb-6">
              Please log in to view your profile and statistics.
            </p>
            <div className="flex gap-4">
              <Button asChild className="flex-1">
                <Link to="/login">Login</Link>
              </Button>
              <Button variant="outline" asChild className="flex-1">
                <Link to="/signup">Sign Up</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="absolute inset-0 grid-pattern opacity-20" />
      
      <div className="relative container mx-auto px-4 py-8">
        <Header showProgress={false} showAuth={true} />

        <div className="max-w-6xl mx-auto">
          {/* Profile Header */}
          <Card className="glass-effect border-border/50 mb-8">
            <CardContent className="p-8">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-6">
                  <div className="w-20 h-20 bg-gradient-to-br from-neon-cyan to-neon-purple rounded-full flex items-center justify-center">
                    <User className="w-10 h-10 text-white" />
                  </div>
                  
                  <div>
                    {isEditing ? (
                      <div className="space-y-2">
                        <input
                          type="text"
                          value={editForm.name}
                          onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                          className="text-2xl font-bold bg-secondary/20 border border-border/50 rounded px-3 py-1"
                        />
                        <input
                          type="email"
                          value={editForm.email}
                          onChange={(e) => setEditForm(prev => ({ ...prev, email: e.target.value }))}
                          className="text-muted-foreground bg-secondary/20 border border-border/50 rounded px-3 py-1"
                        />
                      </div>
                    ) : (
                      <>
                        <h1 className="text-2xl font-bold">{user.name}</h1>
                        <p className="text-muted-foreground">{user.email}</p>
                      </>
                    )}
                    
                    <div className="flex items-center gap-4 mt-2">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Trophy className="w-3 h-3" />
                        Level {userStats.currentLevel}
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        Joined {user.joinDate ? new Date(user.joinDate).toLocaleDateString() : 'Recently'}
                      </Badge>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {isEditing ? (
                    <>
                      <Button variant="outline" size="sm" onClick={handleCancelEdit}>
                        <X className="w-4 h-4 mr-2" />
                        Cancel
                      </Button>
                      <Button size="sm" onClick={handleSaveProfile}>
                        <Save className="w-4 h-4 mr-2" />
                        Save
                      </Button>
                    </>
                  ) : (
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                      <Edit className="w-4 h-4 mr-2" />
                      Edit Profile
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 glass-effect">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="achievements" className="flex items-center gap-2">
                <Award className="w-4 h-4" />
                Achievements
              </TabsTrigger>
              <TabsTrigger value="statistics" className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Statistics
              </TabsTrigger>
              <TabsTrigger value="settings" className="flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Settings
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              {/* Quick Stats */}
              <div className="grid md:grid-cols-4 gap-4">
                <Card className="glass-effect border-border/50">
                  <CardContent className="p-4 text-center">
                    <Brain className="w-8 h-8 mx-auto mb-2 text-neon-cyan" />
                    <div className="text-2xl font-bold">{userStats.avgIQ}</div>
                    <div className="text-sm text-muted-foreground">Average IQ</div>
                  </CardContent>
                </Card>
                
                <Card className="glass-effect border-border/50">
                  <CardContent className="p-4 text-center">
                    <Trophy className="w-8 h-8 mx-auto mb-2 text-yellow-400" />
                    <div className="text-2xl font-bold">{userStats.totalGames}</div>
                    <div className="text-sm text-muted-foreground">Games Played</div>
                  </CardContent>
                </Card>
                
                <Card className="glass-effect border-border/50">
                  <CardContent className="p-4 text-center">
                    <Star className="w-8 h-8 mx-auto mb-2 text-neon-purple" />
                    <div className="text-2xl font-bold">{userStats.avgScore}</div>
                    <div className="text-sm text-muted-foreground">Avg Score</div>
                  </CardContent>
                </Card>
                
                <Card className="glass-effect border-border/50">
                  <CardContent className="p-4 text-center">
                    <Zap className="w-8 h-8 mx-auto mb-2 text-neon-orange" />
                    <div className="text-2xl font-bold">{userStats.bestStreak}</div>
                    <div className="text-sm text-muted-foreground">Best Streak</div>
                  </CardContent>
                </Card>
              </div>

              {/* Progress & Goals */}
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="glass-effect border-border/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5" />
                      Level Progress
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span>Level {userStats.currentLevel}</span>
                      <span>Level {userStats.currentLevel + 1}</span>
                    </div>
                    <Progress value={Math.max(0, Math.min(100, userStats.levelProgress || 0))} className="h-3" />
                    <p className="text-sm text-muted-foreground">
                      {Math.max(0, getNextLevel() - (userStats.totalGames || 0))} more games to level up
                    </p>
                  </CardContent>
                </Card>

                <Card className="glass-effect border-border/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="w-5 h-5" />
                      Weekly Progress
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span>This Week</span>
                      <span>{Math.max(0, Math.min(100, userStats.weeklyProgress || 0))}%</span>
                    </div>
                    <Progress value={Math.max(0, Math.min(100, userStats.weeklyProgress || 0))} className="h-3" />
                    <p className="text-sm text-muted-foreground">
                      Goal: {userStats.monthlyGoal} points this month
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Favorite Room */}
              <Card className="glass-effect border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    Favorite Testing Chamber
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4">
                    {getRoomIcon(userStats.favoriteRoom)}
                    <div>
                      <div className="font-semibold">{userStats.favoriteRoom}</div>
                      <div className="text-sm text-muted-foreground">
                        {Math.floor(userStats.totalGames * 0.4)} games played
                      </div>
                    </div>
                    <Button asChild className="ml-auto">
                      <Link to="/game">Play Now</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Achievements Tab */}
            <TabsContent value="achievements" className="space-y-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {userStats.achievements.map((achievement) => (
                  <Card 
                    key={achievement.id} 
                    className={`glass-effect transition-all ${
                      achievement.earned 
                        ? 'border-yellow-400/50 bg-yellow-400/5' 
                        : 'border-border/50'
                    }`}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="text-3xl">{achievement.icon}</div>
                        <div className="flex-1">
                          <h3 className="font-semibold mb-1">{achievement.title}</h3>
                          <p className="text-sm text-muted-foreground mb-3">
                            {achievement.description}
                          </p>
                          
                          {achievement.earned ? (
                            <Badge className="bg-yellow-400/20 text-yellow-400">
                              <Trophy className="w-3 h-3 mr-1" />
                              Earned {achievement.dateEarned && new Date(achievement.dateEarned).toLocaleDateString()}
                            </Badge>
                          ) : achievement.progress !== undefined ? (
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span>Progress</span>
                                <span>{achievement.progress}/{achievement.maxProgress}</span>
                              </div>
                              <Progress 
                                value={(achievement.progress / (achievement.maxProgress || 1)) * 100} 
                                className="h-2" 
                              />
                            </div>
                          ) : (
                            <Badge variant="outline">Not Started</Badge>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Statistics Tab */}
            <TabsContent value="statistics" className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="glass-effect border-border/50">
                  <CardHeader>
                    <CardTitle>Performance Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="flex items-center gap-2">
                          <Brain className="w-4 h-4 text-neon-cyan" />
                          Logic Chamber
                        </span>
                        <span className="font-semibold">85%</span>
                      </div>
                      <Progress value={85} className="h-2" />
                      
                      <div className="flex justify-between">
                        <span className="flex items-center gap-2">
                          <Target className="w-4 h-4 text-neon-purple" />
                          Pattern Vault
                        </span>
                        <span className="font-semibold">78%</span>
                      </div>
                      <Progress value={78} className="h-2" />
                      
                      <div className="flex justify-between">
                        <span className="flex items-center gap-2">
                          <Brain className="w-4 h-4 text-neon-green" />
                          Memory Core
                        </span>
                        <span className="font-semibold">92%</span>
                      </div>
                      <Progress value={92} className="h-2" />
                      
                      <div className="flex justify-between">
                        <span className="flex items-center gap-2">
                          <Zap className="w-4 h-4 text-neon-orange" />
                          Speed Zone
                        </span>
                        <span className="font-semibold">71%</span>
                      </div>
                      <Progress value={71} className="h-2" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="glass-effect border-border/50">
                  <CardHeader>
                    <CardTitle>Time Analytics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Total Time Played</span>
                      <span className="font-semibold">{(userStats.timeSpent || 0).toFixed(1)} hours</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Average Session</span>
                      <span className="font-semibold">12 minutes</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Longest Session</span>
                      <span className="font-semibold">45 minutes</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Best Time of Day</span>
                      <span className="font-semibold">Evening</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="glass-effect border-border/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Bell className="w-5 h-5" />
                      Notifications
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>Email Notifications</span>
                      <input type="checkbox" defaultChecked className="accent-primary" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Achievement Alerts</span>
                      <input type="checkbox" defaultChecked className="accent-primary" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Weekly Reports</span>
                      <input type="checkbox" className="accent-primary" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="glass-effect border-border/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="w-5 h-5" />
                      Privacy
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>Show on Leaderboard</span>
                      <input type="checkbox" defaultChecked className="accent-primary" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Public Profile</span>
                      <input type="checkbox" className="accent-primary" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Share Achievements</span>
                      <input type="checkbox" defaultChecked className="accent-primary" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Data Export */}
              <Card className="glass-effect border-border/50">
                <CardHeader>
                  <CardTitle>Data & Export</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold">Download Your Data</div>
                      <div className="text-sm text-muted-foreground">
                        Export all your game data, scores, and statistics
                      </div>
                    </div>
                    <Button variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold">Share Profile</div>
                      <div className="text-sm text-muted-foreground">
                        Share your Mind Lab achievements with others
                      </div>
                    </div>
                    <Button variant="outline">
                      <Share2 className="w-4 h-4 mr-2" />
                      Share
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
