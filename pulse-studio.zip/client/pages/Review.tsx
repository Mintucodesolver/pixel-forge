import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { ArrowLeft, Calendar, Clock, Trophy, Target, Brain, Zap, RotateCcw, Download } from 'lucide-react';
import Header from '../components/Header';

export default function Review() {
  const gameHistory = [
    {
      id: 1,
      chamber: 'Logic Chamber',
      icon: Brain,
      color: 'neon-cyan',
      date: '2024-01-15',
      time: '14:30',
      score: 85,
      maxScore: 120,
      accuracy: 75,
      duration: '8:45',
      completed: true
    },
    {
      id: 2,
      chamber: 'Pattern Vault',
      icon: Target,
      color: 'neon-purple',
      date: '2024-01-14',
      time: '16:20',
      score: 92,
      maxScore: 100,
      accuracy: 90,
      duration: '6:32',
      completed: true
    },
    {
      id: 3,
      chamber: 'Logic Chamber',
      icon: Brain,
      color: 'neon-cyan',
      date: '2024-01-13',
      time: '09:15',
      score: 68,
      maxScore: 120,
      accuracy: 58,
      duration: '12:18',
      completed: false
    }
  ];

  const getPerformanceLevel = (accuracy: number) => {
    if (accuracy >= 90) return { label: 'Excellent', color: 'bg-green-500/20 text-green-400' };
    if (accuracy >= 75) return { label: 'Good', color: 'bg-blue-500/20 text-blue-400' };
    if (accuracy >= 60) return { label: 'Average', color: 'bg-yellow-500/20 text-yellow-400' };
    return { label: 'Needs Work', color: 'bg-red-500/20 text-red-400' };
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="absolute inset-0 grid-pattern opacity-20" />
      
      <div className="relative container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/game" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back to Lobby
            </Link>
          </Button>
          <div className="flex-1">
            <Header showProgress={true} progress={65} />
          </div>
        </div>

        {/* Page Title */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-neon-cyan to-neon-purple bg-clip-text text-transparent">
            Game Review Center
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Analyze your past performances and track your cognitive improvement over time
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="glass-effect border-border/50">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-neon-cyan mb-1">3</div>
              <div className="text-xs text-muted-foreground">Games Played</div>
            </CardContent>
          </Card>
          <Card className="glass-effect border-border/50">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-neon-green mb-1">81%</div>
              <div className="text-xs text-muted-foreground">Avg Accuracy</div>
            </CardContent>
          </Card>
          <Card className="glass-effect border-border/50">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-neon-purple mb-1">9:12</div>
              <div className="text-xs text-muted-foreground">Avg Time</div>
            </CardContent>
          </Card>
          <Card className="glass-effect border-border/50">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-neon-orange mb-1">118</div>
              <div className="text-xs text-muted-foreground">Best IQ Score</div>
            </CardContent>
          </Card>
        </div>

        {/* Game History */}
        <div className="space-y-4 mb-8">
          <h2 className="text-2xl font-bold mb-6">Recent Games</h2>
          
          {gameHistory.map((game) => {
            const Icon = game.icon;
            const performance = getPerformanceLevel(game.accuracy);
            
            return (
              <Card key={game.id} className="glass-effect border-border/50 hover:border-border transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 bg-${game.color}/20 rounded-lg flex items-center justify-center`}>
                        <Icon className={`w-6 h-6 text-${game.color}`} />
                      </div>
                      
                      <div>
                        <h3 className="font-semibold text-lg">{game.chamber}</h3>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {game.date} at {game.time}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {game.duration}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-foreground">{game.score}</div>
                        <div className="text-xs text-muted-foreground">/ {game.maxScore}</div>
                      </div>
                      
                      <div className="text-center">
                        <div className="text-lg font-semibold">{game.accuracy}%</div>
                        <Badge className={`text-xs ${performance.color}`}>
                          {performance.label}
                        </Badge>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          <RotateCcw className="w-4 h-4 mr-2" />
                          Retry
                        </Button>
                        <Button size="sm" variant="ghost">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  {!game.completed && (
                    <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                      <div className="flex items-center gap-2 text-yellow-400 text-sm">
                        <Clock className="w-4 h-4" />
                        This game was not completed. You can resume or start over.
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Action Buttons */}
        <div className="flex justify-center gap-4">
          <Button asChild className="animate-pulse-glow">
            <Link to="/game">
              Start New Game
            </Link>
          </Button>
          
          <Button variant="outline" className="glass-effect">
            <Download className="w-4 h-4 mr-2" />
            Export All Data
          </Button>
        </div>
      </div>
    </div>
  );
}
