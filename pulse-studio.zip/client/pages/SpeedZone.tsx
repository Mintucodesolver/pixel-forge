import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Progress } from '../components/ui/progress';
import { Zap, ArrowLeft, Clock, CheckCircle, XCircle, Timer } from 'lucide-react';

interface Puzzle {
  id: number;
  question: string;
  options: string[];
  correct: number;
  difficulty: 'easy' | 'medium' | 'hard' | 'expert';
  timeLimit: number;
  points: number;
  type: 'math' | 'logic' | 'verbal' | 'visual';
}

const puzzles: Puzzle[] = [
  { id: 1, question: "7 + 8 = ?", options: ["14", "15", "16", "17"], correct: 1, difficulty: 'easy', timeLimit: 5, points: 2, type: 'math' },
  { id: 2, question: "Which is bigger: 0.8 or 3/4?", options: ["0.8", "3/4", "Equal", "Can't tell"], correct: 0, difficulty: 'easy', timeLimit: 8, points: 2, type: 'math' },
  { id: 3, question: "CAT : FELINE :: DOG : ?", options: ["CANINE", "PUPPY", "BARK", "PET"], correct: 0, difficulty: 'easy', timeLimit: 7, points: 2, type: 'verbal' },
  { id: 4, question: "15 × 6 = ?", options: ["80", "85", "90", "95"], correct: 2, difficulty: 'easy', timeLimit: 6, points: 2, type: 'math' },
  { id: 5, question: "If today is Wednesday, what day is it in 10 days?", options: ["Thursday", "Friday", "Saturday", "Sunday"], correct: 2, difficulty: 'easy', timeLimit: 10, points: 2, type: 'logic' },
  
  { id: 6, question: "√144 = ?", options: ["11", "12", "13", "14"], correct: 1, difficulty: 'medium', timeLimit: 8, points: 4, type: 'math' },
  { id: 7, question: "Which word doesn't belong: VIOLIN, TRUMPET, PIANO, GUITAR", options: ["VIOLIN", "TRUMPET", "PIANO", "GUITAR"], correct: 1, difficulty: 'medium', timeLimit: 12, points: 4, type: 'verbal' },
  { id: 8, question: "25% of 80 = ?", options: ["15", "20", "25", "30"], correct: 1, difficulty: 'medium', timeLimit: 10, points: 4, type: 'math' },
  { id: 9, question: "If A=1, B=2, C=3... what is CAB?", options: ["8", "9", "6", "7"], correct: 2, difficulty: 'medium', timeLimit: 15, points: 4, type: 'verbal' },
  { id: 10, question: "2³ + 3² = ?", options: ["13", "17", "19", "23"], correct: 1, difficulty: 'medium', timeLimit: 12, points: 4, type: 'math' },
  
  { id: 11, question: "If 3x + 7 = 22, then x = ?", options: ["3", "4", "5", "6"], correct: 2, difficulty: 'hard', timeLimit: 18, points: 6, type: 'math' },
  { id: 12, question: "MODEM reversed and rearranged spells:", options: ["DEMON", "MODEL", "DOMED", "DROME"], correct: 0, difficulty: 'hard', timeLimit: 15, points: 6, type: 'verbal' },
  { id: 13, question: "What's 40% of 150?", options: ["50", "60", "65", "70"], correct: 1, difficulty: 'hard', timeLimit: 12, points: 6, type: 'math' },
  { id: 14, question: "If it takes 5 workers 5 hours to dig 5 holes, how long for 10 workers to dig 10 holes?", options: ["5 hours", "10 hours", "2.5 hours", "20 hours"], correct: 0, difficulty: 'hard', timeLimit: 20, points: 6, type: 'logic' },
  { id: 15, question: "Complete: 2, 6, 18, 54, ?", options: ["108", "162", "216", "270"], correct: 1, difficulty: 'hard', timeLimit: 15, points: 6, type: 'logic' },
  
  { id: 16, question: "∛216 = ?", options: ["4", "5", "6", "7"], correct: 2, difficulty: 'expert', timeLimit: 15, points: 8, type: 'math' },
  { id: 17, question: "If PHONE = 70, what does GRAPH equal?", options: ["65", "68", "72", "75"], correct: 2, difficulty: 'expert', timeLimit: 25, points: 8, type: 'verbal' },
  { id: 18, question: "2^10 = ?", options: ["512", "1024", "2048", "4096"], correct: 1, difficulty: 'expert', timeLimit: 12, points: 8, type: 'math' },
  { id: 19, question: "A train 100m long crosses a 200m bridge in 15 seconds. Speed in m/s?", options: ["15", "20", "25", "30"], correct: 1, difficulty: 'expert', timeLimit: 25, points: 8, type: 'logic' },
  { id: 20, question: "If log₂(x) = 5, then x = ?", options: ["10", "25", "32", "64"], correct: 2, difficulty: 'expert', timeLimit: 20, points: 8, type: 'math' }
];

export default function SpeedZone() {
  const navigate = useNavigate();
  const [currentPuzzle, setCurrentPuzzle] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(puzzles[0]?.timeLimit || 30);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [gameStarted, setGameStarted] = useState(false);
  const [streak, setStreak] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);

  useEffect(() => {
    if (!gameStarted) return;
    
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentPuzzle, gameStarted]);

  const handleTimeUp = () => {
    setShowResult(true);
    setIsCorrect(false);
    setStreak(0);
    setTimeout(() => nextPuzzle(), 1500);
  };

  const handleAnswer = (answerIndex: number) => {
    if (showResult) return;

    setSelectedAnswer(answerIndex);
    const currentPuzzleData = puzzles[currentPuzzle];
    if (!currentPuzzleData) return;

    const correct = answerIndex === currentPuzzleData.correct;

    setIsCorrect(correct);
    setShowResult(true);

    if (correct) {
      const speedBonus = Math.max(0, Math.floor((timeLeft / currentPuzzleData.timeLimit) * currentPuzzleData.points));
      const streakBonus = streak >= 3 ? 2 : 0;
      setScore(prev => prev + currentPuzzleData.points + speedBonus + streakBonus);
      setStreak(prev => {
        const newStreak = prev + 1;
        setMaxStreak(current => Math.max(current, newStreak));
        return newStreak;
      });
    } else {
      setStreak(0);
    }

    setTimeout(() => nextPuzzle(), 1500);
  };

  const nextPuzzle = () => {
    if (currentPuzzle < puzzles.length - 1) {
      setCurrentPuzzle(prev => prev + 1);
      setSelectedAnswer(null);
      setShowResult(false);
      setIsCorrect(null);
      const nextPuzzle = puzzles[currentPuzzle + 1];
      setTimeLeft(nextPuzzle?.timeLimit || 30);
    } else {
      navigate('/results', { state: { score, totalPossible: puzzles.reduce((sum, p) => sum + ((p?.points || 0) * 2), 0), chamber: 'Speed Zone', streak: maxStreak } });
    }
  };

  const startGame = () => {
    setGameStarted(true);
    setTimeLeft(puzzles[0]?.timeLimit || 30);
  };

  const puzzle = puzzles[currentPuzzle] || puzzles[0];
  const progress = puzzles.length > 0 ? ((currentPuzzle + (showResult ? 1 : 0)) / puzzles.length) * 100 : 0;

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="absolute inset-0 grid-pattern opacity-20" />
        
        <Card className="max-w-2xl w-full mx-4 glass-effect border-neon-orange/50">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-neon-orange/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Zap className="w-8 h-8 text-neon-orange" />
            </div>
            <CardTitle className="text-2xl text-neon-orange">Speed Zone</CardTitle>
            <p className="text-muted-foreground">Quick thinking under intense pressure</p>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-4">Challenge Details</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Rapid Questions</div>
                  <div className="text-muted-foreground">{puzzles.length} Challenges</div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Difficulty</div>
                  <div className="text-muted-foreground">Rapid Fire</div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Time Pressure</div>
                  <div className="text-muted-foreground">5-25s each</div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Bonus System</div>
                  <div className="text-muted-foreground">Speed + Streak</div>
                </div>
              </div>
            </div>
            
            <div className="text-center bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4">
              <div className="flex items-center justify-center gap-2 text-yellow-400 text-sm mb-2">
                <Timer className="w-4 h-4" />
                <span className="font-semibold">Speed Challenge Rules</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Answer quickly for speed bonuses. Build streaks for extra points. Time pressure increases as you progress!
              </p>
            </div>
            
            <div className="flex gap-4">
              <Button variant="outline" asChild className="flex-1">
                <Link to="/game">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Lobby
                </Link>
              </Button>
              <Button onClick={startGame} className="flex-1 animate-pulse-glow bg-neon-orange hover:bg-neon-orange/90">
                Start Challenge
                <Zap className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="absolute inset-0 grid-pattern opacity-20" />
      
      <div className="relative container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-neon-orange/20 rounded-lg flex items-center justify-center">
              <Zap className="w-4 h-4 text-neon-orange" />
            </div>
            <span className="text-lg font-bold text-neon-orange">Speed Zone</span>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Score</div>
              <div className="text-lg font-bold text-neon-orange">{score}</div>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Streak</div>
              <div className={`text-lg font-bold ${streak >= 3 ? 'text-neon-green' : 'text-foreground'}`}>
                {streak} {streak >= 3 && '🔥'}
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Time</div>
              <div className={`text-2xl font-bold ${timeLeft <= 3 ? 'text-destructive animate-pulse' : timeLeft <= 5 ? 'text-yellow-400' : 'text-neon-orange'}`}>
                {timeLeft}
              </div>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <div className="flex justify-between text-sm mb-2">
            <span>Question {currentPuzzle + 1} of {puzzles.length}</span>
            <span>{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-3" />
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="glass-effect border-border/50 mb-8">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    (puzzle?.difficulty || 'easy') === 'easy' ? 'bg-green-500/20 text-green-400' :
                    (puzzle?.difficulty || 'easy') === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                    (puzzle?.difficulty || 'easy') === 'hard' ? 'bg-orange-500/20 text-orange-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {(puzzle?.difficulty || 'easy').toUpperCase()}
                  </span>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    (puzzle?.type || 'math') === 'math' ? 'bg-blue-500/20 text-blue-400' :
                    (puzzle?.type || 'math') === 'logic' ? 'bg-purple-500/20 text-purple-400' :
                    (puzzle?.type || 'math') === 'verbal' ? 'bg-green-500/20 text-green-400' :
                    'bg-cyan-500/20 text-cyan-400'
                  }`}>
                    {(puzzle?.type || 'math').toUpperCase()}
                  </span>
                  <span className="text-sm text-muted-foreground">{puzzle?.points || 0} pts</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">{puzzle?.timeLimit || 30}s</span>
                </div>
              </div>
              <CardTitle className="text-2xl leading-relaxed font-mono">{puzzle?.question || 'Loading...'}</CardTitle>
            </CardHeader>
            
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                {(puzzle?.options || []).map((option, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className={`p-6 h-auto text-left justify-start transition-all duration-200 text-lg font-mono ${
                      showResult && index === (puzzle?.correct || 0)
                        ? 'border-neon-green bg-neon-green/10 text-neon-green'
                        : showResult && selectedAnswer === index && index !== (puzzle?.correct || 0)
                        ? 'border-destructive bg-destructive/10 text-destructive'
                        : selectedAnswer === index
                        ? 'border-neon-orange bg-neon-orange/10'
                        : 'border-border hover:border-neon-orange/50'
                    } ${showResult ? 'cursor-default' : 'cursor-pointer hover:scale-[1.02] active:scale-[0.98]'}`}
                    onClick={() => handleAnswer(index)}
                    disabled={showResult}
                  >
                    <div className="flex items-center gap-3">
                      <span className="flex items-center justify-center w-8 h-8 rounded-full bg-secondary text-sm font-bold">
                        {String.fromCharCode(65 + index)}
                      </span>
                      <span className="flex-1">{option}</span>
                      {showResult && index === (puzzle?.correct || 0) && (
                        <CheckCircle className="w-6 h-6 text-neon-green" />
                      )}
                      {showResult && selectedAnswer === index && index !== (puzzle?.correct || 0) && (
                        <XCircle className="w-6 h-6 text-destructive" />
                      )}
                    </div>
                  </Button>
                ))}
              </div>
              
              {showResult && (
                <div className="mt-6 text-center">
                  <div className={`text-xl font-bold ${isCorrect ? 'text-neon-green' : 'text-destructive'}`}>
                    {isCorrect ? (timeLeft > puzzle.timeLimit * 0.7 ? 'Lightning Fast!' : 'Correct!') : 'Too Slow!'}
                  </div>
                  {isCorrect && (
                    <div className="text-sm text-muted-foreground mt-1">
                      +{(puzzle?.points || 0) + Math.max(0, Math.floor((timeLeft / (puzzle?.timeLimit || 30)) * (puzzle?.points || 0))) + (streak >= 2 ? 2 : 0)} points
                      {timeLeft > (puzzle?.timeLimit || 30) * 0.7 && (
                        <span className="text-neon-orange ml-1">(Speed Demon!)</span>
                      )}
                      {streak >= 3 && (
                        <span className="text-neon-green ml-1">(Streak Bonus!)</span>
                      )}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
