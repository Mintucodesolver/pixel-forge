import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Progress } from "../components/ui/progress";
import {
  Brain,
  Target,
  Clock,
  Zap,
  ArrowLeft,
  Play,
  Lock,
  Star,
  RotateCcw,
  Lightbulb,
  Box,
} from "lucide-react";
import Header from "../components/Header";

export default function Game() {
  const [selectedRoom, setSelectedRoom] = useState<string | null>(null);

  const rooms = [
    {
      id: "logic",
      name: "Logic Chamber",
      description: "Test your reasoning and problem-solving abilities",
      icon: Brain,
      color: "neon-cyan",
      difficulty: "Progressive",
      timeLimit: "30-60s per puzzle",
      puzzles: 12,
      unlocked: true,
    },
    {
      id: "pattern",
      name: "Pattern Vault",
      description: "Discover hidden patterns and sequences",
      icon: Target,
      color: "neon-purple",
      difficulty: "Adaptive",
      timeLimit: "40-50s per puzzle",
      puzzles: 10,
      unlocked: true,
    },
    {
      id: "memory",
      name: "Memory Core",
      description: "Challenge your short and long-term memory",
      icon: Brain,
      color: "neon-green",
      difficulty: "Escalating",
      timeLimit: "15-60s per puzzle",
      puzzles: 12,
      unlocked: true,
    },
    {
      id: "speed",
      name: "Speed Zone",
      description: "Quick thinking under intense pressure",
      icon: Zap,
      color: "neon-orange",
      difficulty: "Rapid Fire",
      timeLimit: "5-30s per puzzle",
      puzzles: 20,
      unlocked: true,
    },
    {
      id: "creativity",
      name: "Creativity Chamber",
      description: "Unleash creative and lateral thinking",
      icon: Lightbulb,
      color: "pink-500",
      difficulty: "Innovative",
      timeLimit: "60-120s per puzzle",
      puzzles: 15,
      unlocked: true,
    },
    {
      id: "spatial",
      name: "Spatial Lab",
      description: "Master 3D reasoning and spatial intelligence",
      icon: Box,
      color: "teal-500",
      difficulty: "Dimensional",
      timeLimit: "45-90s per puzzle",
      puzzles: 14,
      unlocked: true,
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="absolute inset-0 grid-pattern opacity-20" />

      <div className="relative container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back
            </Link>
          </Button>
          <div className="flex-1">
            <Header showProgress={true} progress={25} />
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-neon-cyan to-neon-purple bg-clip-text text-transparent">
              Select Your Testing Chamber
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-6">
              Each chamber tests different aspects of intelligence. Complete
              them in order to unlock advanced challenges.
            </p>

            <div className="flex justify-center gap-4">
              <Button variant="outline" asChild className="glass-effect">
                <Link to="/review" className="flex items-center gap-2">
                  <RotateCcw className="w-4 h-4" />
                  Review Past Games
                </Link>
              </Button>
            </div>
          </div>

          {/* Room Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {rooms.map((room, index) => {
              const Icon = room.icon;
              const isSelected = selectedRoom === room.id;

              return (
                <Card
                  key={room.id}
                  className={`cursor-pointer transition-all duration-300 glass-effect relative overflow-hidden ${
                    isSelected
                      ? `border-${room.color}/80 shadow-lg shadow-${room.color}/20`
                      : "border-border/50 hover:border-border"
                  } ${!room.unlocked ? "opacity-50" : ""}`}
                  onClick={() => room.unlocked && setSelectedRoom(room.id)}
                >
                  {!room.unlocked && (
                    <div className="absolute top-4 right-4 z-10">
                      <Lock className="w-5 h-5 text-muted-foreground" />
                    </div>
                  )}

                  <CardHeader className="pb-4">
                    <div className="flex items-center justify-between">
                      <div
                        className={`w-12 h-12 bg-${room.color}/20 rounded-lg flex items-center justify-center`}
                      >
                        <Icon className={`w-6 h-6 text-${room.color}`} />
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground">
                          Chamber {index + 1}
                        </div>
                        {room.unlocked && (
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-yellow-400" />
                            <Star className="w-4 h-4 text-yellow-400" />
                            <Star className="w-4 h-4 text-muted-foreground" />
                          </div>
                        )}
                      </div>
                    </div>
                    <CardTitle className="text-xl">{room.name}</CardTitle>
                  </CardHeader>

                  <CardContent>
                    <p className="text-muted-foreground mb-4">
                      {room.description}
                    </p>

                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Puzzles:</span>
                        <span>{room.puzzles}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">
                          Difficulty:
                        </span>
                        <span>{room.difficulty}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">
                          Time Limit:
                        </span>
                        <span>{room.timeLimit}</span>
                      </div>
                    </div>

                    {isSelected && room.unlocked && (
                      <Button
                        className="w-full mt-4 animate-pulse-glow"
                        asChild
                      >
                        <Link
                          to={`/game/${room.id}`}
                          className="flex items-center justify-center gap-2"
                        >
                          <Play className="w-4 h-4" />
                          Enter Chamber
                        </Link>
                      </Button>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Instructions */}
          <Card className="glass-effect border-border/50 max-w-4xl mx-auto">
            <CardHeader>
              <CardTitle className="text-center">How It Works</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6 text-center">
                <div>
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-lg font-bold text-primary">1</span>
                  </div>
                  <h3 className="font-semibold mb-2">Choose Chamber</h3>
                  <p className="text-sm text-muted-foreground">
                    Select a testing chamber to begin your IQ assessment
                  </p>
                </div>
                <div>
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-lg font-bold text-primary">2</span>
                  </div>
                  <h3 className="font-semibold mb-2">Solve Puzzles</h3>
                  <p className="text-sm text-muted-foreground">
                    Complete challenges with accuracy and speed for maximum
                    points
                  </p>
                </div>
                <div>
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-lg font-bold text-primary">3</span>
                  </div>
                  <h3 className="font-semibold mb-2">Get Results</h3>
                  <p className="text-sm text-muted-foreground">
                    Receive your personalized Brain Report with IQ score
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
