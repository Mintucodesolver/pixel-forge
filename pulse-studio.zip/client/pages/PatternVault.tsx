import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Progress } from '../components/ui/progress';
import { Target, ArrowLeft, Clock, Zap, CheckCircle, XCircle } from 'lucide-react';

interface Puzzle {
  id: number;
  question: string;
  options: string[];
  correct: number;
  difficulty: 'easy' | 'medium' | 'hard' | 'expert';
  timeLimit: number;
  points: number;
}

const puzzles: Puzzle[] = [
  {
    id: 1,
    question: "What comes next in the pattern: ○ ● ○ ● ○ ?",
    options: ["○", "●", "◐", "◑"],
    correct: 1,
    difficulty: 'easy',
    timeLimit: 30,
    points: 5
  },
  {
    id: 2,
    question: "Complete the sequence: 2, 6, 18, 54, ?",
    options: ["108", "162", "216", "270"],
    correct: 1,
    difficulty: 'easy',
    timeLimit: 30,
    points: 5
  },
  {
    id: 3,
    question: "Which shape comes next: △ ▢ ○ △ ▢ ?",
    options: ["△", "▢", "○", "◇"],
    correct: 2,
    difficulty: 'easy',
    timeLimit: 30,
    points: 5
  },
  {
    id: 4,
    question: "Find the pattern: A1, C3, E5, G7, ?",
    options: ["H8", "I9", "J10", "K11"],
    correct: 1,
    difficulty: 'medium',
    timeLimit: 40,
    points: 10
  },
  {
    id: 5,
    question: "What number continues this pattern: 1, 4, 9, 16, 25, ?",
    options: ["30", "32", "36", "40"],
    correct: 2,
    difficulty: 'medium',
    timeLimit: 40,
    points: 10
  },
  {
    id: 6,
    question: "Complete the sequence: 3, 7, 15, 31, ?",
    options: ["47", "55", "63", "71"],
    correct: 2,
    difficulty: 'medium',
    timeLimit: 40,
    points: 10
  },
  {
    id: 7,
    question: "In a 3x3 grid, if the pattern is: [●○●] [○●○] [●○?], what goes in the ?",
    options: ["●", "○", "◐", "Nothing"],
    correct: 0,
    difficulty: 'hard',
    timeLimit: 50,
    points: 15
  },
  {
    id: 8,
    question: "Which number is missing: 2, 3, 5, 8, 13, ?, 34",
    options: ["18", "20", "21", "24"],
    correct: 2,
    difficulty: 'hard',
    timeLimit: 50,
    points: 15
  },
  {
    id: 9,
    question: "Find the pattern: AZ, BY, CX, DW, ?",
    options: ["EV", "FU", "EX", "FV"],
    correct: 0,
    difficulty: 'expert',
    timeLimit: 60,
    points: 20
  },
  {
    id: 10,
    question: "Complete this complex pattern: 1, 11, 21, 1211, 111221, ?",
    options: ["112211", "312211", "13112221", "31121211"],
    correct: 1,
    difficulty: 'expert',
    timeLimit: 60,
    points: 20
  }
];

export default function PatternVault() {
  const navigate = useNavigate();
  const [currentPuzzle, setCurrentPuzzle] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(puzzles[0].timeLimit);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [gameStarted, setGameStarted] = useState(false);

  useEffect(() => {
    if (!gameStarted) return;
    
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentPuzzle, gameStarted]);

  const handleTimeUp = () => {
    setShowResult(true);
    setIsCorrect(false);
    setTimeout(() => nextPuzzle(), 2000);
  };

  const handleAnswer = (answerIndex: number) => {
    if (showResult) return;

    setSelectedAnswer(answerIndex);
    const puzzle = puzzles[currentPuzzle];
    if (!puzzle) return;

    const correct = answerIndex === puzzle.correct;

    setIsCorrect(correct);
    setShowResult(true);

    if (correct) {
      const speedBonus = Math.floor((timeLeft / puzzle.timeLimit) * 5);
      setScore(prev => prev + puzzle.points + speedBonus);
    }

    setTimeout(() => nextPuzzle(), 2000);
  };

  const nextPuzzle = () => {
    if (currentPuzzle < puzzles.length - 1) {
      setCurrentPuzzle(prev => prev + 1);
      setSelectedAnswer(null);
      setShowResult(false);
      setIsCorrect(null);
      const nextPuzzle = puzzles[currentPuzzle + 1];
      setTimeLeft(nextPuzzle?.timeLimit || 30);
    } else {
      // Game finished - navigate to results
      navigate('/results', { state: { score, totalPossible: puzzles.reduce((sum, p) => sum + (p?.points || 0) + 5, 0), chamber: 'Pattern Vault' } });
    }
  };

  const startGame = () => {
    setGameStarted(true);
    setTimeLeft(puzzles[0]?.timeLimit || 30);
  };

  const puzzle = puzzles[currentPuzzle] || puzzles[0];
  const progress = puzzles.length > 0 ? ((currentPuzzle + (showResult ? 1 : 0)) / puzzles.length) * 100 : 0;

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="absolute inset-0 grid-pattern opacity-20" />
        
        <Card className="max-w-2xl w-full mx-4 glass-effect border-neon-purple/50">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-neon-purple/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Target className="w-8 h-8 text-neon-purple" />
            </div>
            <CardTitle className="text-2xl text-neon-purple">Pattern Vault</CardTitle>
            <p className="text-muted-foreground">Discover hidden patterns and sequences</p>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-4">Challenge Details</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Puzzles</div>
                  <div className="text-muted-foreground">{puzzles.length} Patterns</div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Difficulty</div>
                  <div className="text-muted-foreground">Adaptive</div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Time Limit</div>
                  <div className="text-muted-foreground">30-60s each</div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Scoring</div>
                  <div className="text-muted-foreground">Pattern + Speed</div>
                </div>
              </div>
            </div>
            
            <div className="flex gap-4">
              <Button variant="outline" asChild className="flex-1">
                <Link to="/game">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Lobby
                </Link>
              </Button>
              <Button onClick={startGame} className="flex-1 animate-pulse-glow bg-neon-purple hover:bg-neon-purple/90">
                Start Challenge
                <Zap className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="absolute inset-0 grid-pattern opacity-20" />
      
      <div className="relative container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-neon-purple/20 rounded-lg flex items-center justify-center">
              <Target className="w-4 h-4 text-neon-purple" />
            </div>
            <span className="text-lg font-bold text-neon-purple">Pattern Vault</span>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Score</div>
              <div className="text-lg font-bold text-neon-purple">{score}</div>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Time</div>
              <div className={`text-lg font-bold ${timeLeft <= 10 ? 'text-destructive' : 'text-neon-orange'}`}>
                {timeLeft}s
              </div>
            </div>
          </div>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between text-sm mb-2">
            <span>Pattern {currentPuzzle + 1} of {puzzles.length}</span>
            <span>{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Puzzle */}
        <div className="max-w-4xl mx-auto">
          <Card className="glass-effect border-border/50 mb-8">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    puzzle.difficulty === 'easy' ? 'bg-green-500/20 text-green-400' :
                    puzzle.difficulty === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                    puzzle.difficulty === 'hard' ? 'bg-orange-500/20 text-orange-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {puzzle.difficulty.toUpperCase()}
                  </span>
                  <span className="text-sm text-muted-foreground">{puzzle.points} points</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">{puzzle.timeLimit}s</span>
                </div>
              </div>
              <CardTitle className="text-xl leading-relaxed font-mono">{puzzle.question}</CardTitle>
            </CardHeader>
            
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {puzzle.options.map((option, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className={`p-6 h-auto text-left justify-start transition-all duration-300 font-mono text-lg ${
                      showResult && index === puzzle.correct
                        ? 'border-neon-green bg-neon-green/10 text-neon-green'
                        : showResult && selectedAnswer === index && index !== puzzle.correct
                        ? 'border-destructive bg-destructive/10 text-destructive'
                        : selectedAnswer === index
                        ? 'border-neon-purple bg-neon-purple/10'
                        : 'border-border hover:border-neon-purple/50'
                    } ${showResult ? 'cursor-default' : 'cursor-pointer hover:scale-[1.02]'}`}
                    onClick={() => handleAnswer(index)}
                    disabled={showResult}
                  >
                    <div className="flex items-center gap-3">
                      <span className="flex items-center justify-center w-6 h-6 rounded-full bg-secondary text-sm font-medium">
                        {String.fromCharCode(65 + index)}
                      </span>
                      <span className="flex-1">{option}</span>
                      {showResult && index === puzzle.correct && (
                        <CheckCircle className="w-5 h-5 text-neon-green" />
                      )}
                      {showResult && selectedAnswer === index && index !== puzzle.correct && (
                        <XCircle className="w-5 h-5 text-destructive" />
                      )}
                    </div>
                  </Button>
                ))}
              </div>
              
              {showResult && (
                <div className="mt-6 text-center">
                  <div className={`text-lg font-semibold ${isCorrect ? 'text-neon-green' : 'text-destructive'}`}>
                    {isCorrect ? 'Pattern Recognized!' : 'Pattern Missed'}
                  </div>
                  {isCorrect && (
                    <div className="text-sm text-muted-foreground mt-1">
                      +{puzzle.points + Math.floor((timeLeft / puzzle.timeLimit) * 5)} points
                      {timeLeft > puzzle.timeLimit * 0.5 && (
                        <span className="text-neon-orange ml-1">(Speed Bonus!)</span>
                      )}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
