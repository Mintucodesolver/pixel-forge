import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Progress } from '../components/ui/progress';
import {
  Brain,
  Trophy,
  Target,
  Clock,
  Zap,
  RotateCcw,
  Share2,
  Download,
  Home,
  TrendingUp,
  Award
} from 'lucide-react';
import Rating from '../components/Rating';

export default function Results() {
  const location = useLocation();
  const { score = 45, totalPossible = 80 } = location.state || {};
  
  const percentage = Math.round((score / totalPossible) * 100);
  const iqScore = Math.round(85 + (percentage * 0.5)); // Simplified IQ calculation
  
  const getIQCategory = (iq: number) => {
    if (iq >= 130) return { category: 'Genius', color: 'neon-purple', description: 'Exceptional intellect' };
    if (iq >= 115) return { category: 'Above Average', color: 'neon-cyan', description: 'Superior cognitive ability' };
    if (iq >= 85) return { category: 'Average', color: 'neon-green', description: 'Normal intelligence range' };
    return { category: 'Below Average', color: 'neon-orange', description: 'Room for improvement' };
  };

  const iqCategory = getIQCategory(iqScore);
  
  const strengths = [
    { area: 'Logical Reasoning', score: 85, description: 'Strong pattern recognition and deductive thinking' },
    { area: 'Problem Solving', score: 75, description: 'Good at breaking down complex problems' },
    { area: 'Speed Processing', score: 60, description: 'Moderate pace in time-pressured situations' },
  ];

  const improvements = [
    { area: 'Working Memory', suggestion: 'Practice memory exercises and chunking techniques' },
    { area: 'Spatial Reasoning', suggestion: 'Try 3D puzzles and visualization exercises' },
    { area: 'Processing Speed', suggestion: 'Practice timed mental math and quick decision making' },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="absolute inset-0 grid-pattern opacity-20" />
      
      <div className="relative container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse-glow">
            <Trophy className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-neon-cyan to-neon-purple bg-clip-text text-transparent">
            Your Brain Report
          </h1>
          <p className="text-lg text-muted-foreground">Complete analysis of your cognitive performance</p>
        </div>

        <div className="max-w-6xl mx-auto grid lg:grid-cols-3 gap-8">
          {/* Main Score Card */}
          <div className="lg:col-span-2">
            <Card className="glass-effect border-border/50 mb-8">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">Overall IQ Score</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="relative inline-flex items-center justify-center w-48 h-48 mx-auto mb-6">
                  <svg className="w-48 h-48 transform -rotate-90" viewBox="0 0 200 200">
                    <circle
                      cx="100"
                      cy="100"
                      r="80"
                      stroke="hsl(var(--border))"
                      strokeWidth="8"
                      fill="none"
                    />
                    <circle
                      cx="100"
                      cy="100"
                      r="80"
                      stroke={`hsl(var(--${iqCategory.color}))`}
                      strokeWidth="8"
                      fill="none"
                      strokeLinecap="round"
                      strokeDasharray={`${(iqScore / 200) * 502} 502`}
                      className="transition-all duration-1000 ease-out"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <div className={`text-5xl font-bold text-${iqCategory.color} neon-glow`}>
                      {iqScore}
                    </div>
                    <div className="text-sm text-muted-foreground">IQ Score</div>
                  </div>
                </div>
                
                <div className={`text-2xl font-bold text-${iqCategory.color} mb-2`}>
                  {iqCategory.category}
                </div>
                <p className="text-muted-foreground mb-6">{iqCategory.description}</p>
                
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="bg-secondary/20 rounded-lg p-4">
                    <div className="text-2xl font-bold text-neon-cyan">{score}</div>
                    <div className="text-sm text-muted-foreground">Points Earned</div>
                  </div>
                  <div className="bg-secondary/20 rounded-lg p-4">
                    <div className="text-2xl font-bold text-neon-green">{percentage}%</div>
                    <div className="text-sm text-muted-foreground">Accuracy</div>
                  </div>
                  <div className="bg-secondary/20 rounded-lg p-4">
                    <div className="text-2xl font-bold text-neon-orange">Top 25%</div>
                    <div className="text-sm text-muted-foreground">Percentile</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Cognitive Strengths */}
            <Card className="glass-effect border-border/50 mb-8">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-neon-green" />
                  Cognitive Strengths
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {strengths.map((strength, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">{strength.area}</span>
                      <span className="text-sm text-muted-foreground">{strength.score}/100</span>
                    </div>
                    <Progress value={strength.score} className="mb-2" />
                    <p className="text-sm text-muted-foreground">{strength.description}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Areas for Improvement */}
            <Card className="glass-effect border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-neon-orange" />
                  Areas for Growth
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {improvements.map((area, index) => (
                  <div key={index} className="bg-secondary/20 rounded-lg p-4">
                    <h4 className="font-semibold mb-2">{area.area}</h4>
                    <p className="text-sm text-muted-foreground">{area.suggestion}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <Card className="glass-effect border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Brain className="w-4 h-4 text-neon-cyan" />
                    <span className="text-sm">Chambers Completed</span>
                  </div>
                  <span className="font-semibold">1/4</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-neon-orange" />
                    <span className="text-sm">Average Time</span>
                  </div>
                  <span className="font-semibold">28s</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-neon-green" />
                    <span className="text-sm">Speed Bonuses</span>
                  </div>
                  <span className="font-semibold">3</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-neon-purple" />
                    <span className="text-sm">Global Rank</span>
                  </div>
                  <span className="font-semibold">#1,247</span>
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <Card className="glass-effect border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Next Steps</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button asChild className="w-full">
                  <Link to="/game" className="flex items-center justify-center gap-2">
                    <RotateCcw className="w-4 h-4" />
                    Continue Testing
                  </Link>
                </Button>
                
                <Button variant="outline" className="w-full">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share Results
                </Button>
                
                <Button variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Download Report
                </Button>
                
                <Button variant="ghost" asChild className="w-full">
                  <Link to="/" className="flex items-center justify-center gap-2">
                    <Home className="w-4 h-4" />
                    Back to Home
                  </Link>
                </Button>
              </CardContent>
            </Card>

            {/* Achievement */}
            <Card className="glass-effect border-neon-purple/30">
              <CardContent className="p-4 text-center">
                <div className="w-12 h-12 bg-neon-purple/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Trophy className="w-6 h-6 text-neon-purple" />
                </div>
                <h3 className="font-semibold text-neon-purple mb-1">Chamber Complete!</h3>
                <p className="text-xs text-muted-foreground">You've successfully completed the {location.state?.chamber || 'challenge'}</p>
              </CardContent>
            </Card>

            {/* Rate Your Experience */}
            <Card className="glass-effect border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Rate Your Experience</CardTitle>
              </CardHeader>
              <CardContent>
                <Rating compact={false} showTitle={false} />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
