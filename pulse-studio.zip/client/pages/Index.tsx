import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import {
  Brain,
  Zap,
  Target,
  Clock,
  Trophy,
  ChevronRight,
  RotateCcw,
  Lightbulb,
  Box,
  User,
  LogIn,
} from "lucide-react";
import Rating from "../components/Rating";
import AuthModals from "../components/AuthModals";
import { useAuth } from "../components/AuthContext";

export default function Index() {
  const { isAuthenticated, user, logout } = useAuth();
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [signupModalOpen, setSignupModalOpen] = useState(false);

  const handleSwitchToSignup = () => {
    setLoginModalOpen(false);
    setSignupModalOpen(true);
  };

  const handleSwitchToLogin = () => {
    setSignupModalOpen(false);
    setLoginModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Grid Pattern Background */}
      <div className="absolute inset-0 grid-pattern opacity-30" />

      {/* Hero Section */}
      <div className="relative">
        <div className="container mx-auto px-4 py-12">
          {/* Header */}
          <div className="flex items-center justify-between mb-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center animate-pulse-glow">
                <Brain className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-2xl font-bold text-neon-cyan neon-glow">
                Mind Lab
              </span>
            </div>
            <nav className="flex items-center space-x-6">
              <Link
                to="/leaderboard"
                className="hidden md:block text-muted-foreground hover:text-neon-cyan transition-colors"
              >
                Leaderboard
              </Link>
              <Link
                to="/about"
                className="hidden md:block text-muted-foreground hover:text-neon-cyan transition-colors"
              >
                About
              </Link>

              {/* Authentication Section */}
              {isAuthenticated && user ? (
                <div className="flex items-center gap-2">
                  <div className="text-right hidden sm:block">
                    <div className="text-sm font-medium">Welcome back,</div>
                    <div className="text-xs text-muted-foreground">
                      {user.name}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="sm" asChild>
                      <Link to="/profile" className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        <span className="hidden md:inline">Profile</span>
                      </Link>
                    </Button>
                    <Button variant="ghost" size="sm" onClick={logout}>
                      <LogIn className="w-4 h-4 rotate-180" />
                      <span className="hidden md:inline ml-2">Logout</span>
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex items-center gap-2"
                    onClick={() => setLoginModalOpen(true)}
                  >
                    <LogIn className="w-4 h-4" />
                    <span className="hidden sm:inline">Login</span>
                  </Button>
                  <Button
                    size="sm"
                    className="animate-pulse-glow flex items-center gap-2"
                    onClick={() => setSignupModalOpen(true)}
                  >
                    <User className="w-4 h-4" />
                    <span className="hidden sm:inline">Sign Up</span>
                  </Button>
                </div>
              )}
            </nav>
          </div>

          {/* Hero Content */}
          <div className="text-center mb-20">
            <div className="inline-flex items-center gap-2 bg-secondary/50 px-4 py-2 rounded-full mb-6 glass-effect">
              <Zap className="w-4 h-4 text-neon-green" />
              <span className="text-sm text-muted-foreground">
                Advanced IQ Testing Platform
              </span>
            </div>

            {isAuthenticated && user ? (
              <div className="mb-6">
                <h2 className="text-2xl md:text-3xl font-bold text-neon-cyan mb-2">
                  Welcome back, {user.name}!
                </h2>
                <p className="text-lg text-muted-foreground">
                  Ready to continue your IQ journey?
                </p>
              </div>
            ) : (
              <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-neon-cyan via-neon-purple to-neon-green bg-clip-text text-transparent animate-float">
                Mind Lab
              </h1>
            )}

            <p className="text-xl md:text-2xl text-muted-foreground mb-4 max-w-3xl mx-auto">
              The IQ Adventure
            </p>

            <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed">
              {isAuthenticated
                ? "Continue testing different aspects of your intelligence across our virtual science lab chambers."
                : "Enter the virtual science lab where each room tests different aspects of your intelligence. Solve logic, pattern, memory, and speed puzzles to discover your true IQ potential."}
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                asChild
                size="lg"
                className="text-lg px-8 py-6 bg-primary hover:bg-primary/90 text-primary-foreground animate-pulse-glow"
              >
                <Link to="/game" className="flex items-center gap-2">
                  {isAuthenticated ? "Continue Testing" : "Start IQ Test"}
                  <ChevronRight className="w-5 h-5" />
                </Link>
              </Button>

              {!isAuthenticated && (
                <Button
                  variant="outline"
                  size="lg"
                  asChild
                  className="text-lg px-8 py-6 border-border hover:bg-secondary/50 glass-effect"
                >
                  <Link to="/demo">Try Demo</Link>
                </Button>
              )}

              {isAuthenticated && (
                <Button
                  variant="outline"
                  size="lg"
                  asChild
                  className="text-lg px-8 py-6 border-border hover:bg-secondary/50 glass-effect"
                >
                  <Link to="/profile">View Profile</Link>
                </Button>
              )}
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
            <Card className="glass-effect border-border/50 hover:border-neon-cyan/50 transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-neon-cyan/20 rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:animate-pulse-glow">
                  <Brain className="w-6 h-6 text-neon-cyan" />
                </div>
                <h3 className="font-semibold mb-2 text-foreground">
                  Logic Chamber
                </h3>
                <p className="text-sm text-muted-foreground">
                  Complex reasoning and problem-solving challenges
                </p>
              </CardContent>
            </Card>

            <Card className="glass-effect border-border/50 hover:border-neon-purple/50 transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-neon-purple/20 rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:animate-pulse-glow">
                  <Target className="w-6 h-6 text-neon-purple" />
                </div>
                <h3 className="font-semibold mb-2 text-foreground">
                  Pattern Vault
                </h3>
                <p className="text-sm text-muted-foreground">
                  Discover hidden patterns and sequences
                </p>
              </CardContent>
            </Card>

            <Card className="glass-effect border-border/50 hover:border-neon-green/50 transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-neon-green/20 rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:animate-pulse-glow">
                  <Brain className="w-6 h-6 text-neon-green" />
                </div>
                <h3 className="font-semibold mb-2 text-foreground">
                  Memory Core
                </h3>
                <p className="text-sm text-muted-foreground">
                  Test your short and long-term memory
                </p>
              </CardContent>
            </Card>

            <Card className="glass-effect border-border/50 hover:border-neon-orange/50 transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-neon-orange/20 rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:animate-pulse-glow">
                  <Clock className="w-6 h-6 text-neon-orange" />
                </div>
                <h3 className="font-semibold mb-2 text-foreground">
                  Speed Zone
                </h3>
                <p className="text-sm text-muted-foreground">
                  Quick thinking under pressure
                </p>
              </CardContent>
            </Card>

            <Card className="glass-effect border-border/50 hover:border-pink-500/50 transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-pink-500/20 rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:animate-pulse-glow">
                  <Lightbulb className="w-6 h-6 text-pink-500" />
                </div>
                <h3 className="font-semibold mb-2 text-foreground">
                  Creativity Chamber
                </h3>
                <p className="text-sm text-muted-foreground">
                  Unleash creative and lateral thinking
                </p>
              </CardContent>
            </Card>

            <Card className="glass-effect border-border/50 hover:border-teal-500/50 transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-teal-500/20 rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:animate-pulse-glow">
                  <Box className="w-6 h-6 text-teal-500" />
                </div>
                <h3 className="font-semibold mb-2 text-foreground">
                  Spatial Lab
                </h3>
                <p className="text-sm text-muted-foreground">
                  Master 3D reasoning and spatial intelligence
                </p>
              </CardContent>
            </Card>
          </div>

          {/* IQ Scoring Info */}
          <div className="text-center mb-20">
            <h2 className="text-3xl font-bold mb-8 text-foreground">
              Your Brain Report Awaits
            </h2>
            <div className="grid sm:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="text-4xl font-bold text-neon-green mb-2">
                  0-30
                </div>
                <div className="text-lg font-semibold mb-1">Average</div>
                <div className="text-sm text-muted-foreground">
                  Solid foundation
                </div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-neon-cyan mb-2">
                  31-60
                </div>
                <div className="text-lg font-semibold mb-1">Above Average</div>
                <div className="text-sm text-muted-foreground">
                  Sharp thinking
                </div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-neon-purple mb-2">
                  61+
                </div>
                <div className="text-lg font-semibold mb-1">Genius</div>
                <div className="text-sm text-muted-foreground">
                  Exceptional mind
                </div>
              </div>
            </div>
          </div>

          {/* Rating Section */}
          <div className="max-w-4xl mx-auto mb-20">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-4 text-foreground">
                What Players Are Saying
              </h2>
              <p className="text-muted-foreground">
                Join thousands of players who have tested their IQ with Mind Lab
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <Rating />
              </div>
              <div className="space-y-6">
                <div className="bg-secondary/10 rounded-lg p-6 glass-effect">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <svg
                          key={star}
                          className="w-4 h-4 text-yellow-400 fill-yellow-400"
                          viewBox="0 0 24 24"
                        >
                          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                        </svg>
                      ))}
                    </div>
                    <span className="text-sm text-muted-foreground">
                      Sarah M.
                    </span>
                  </div>
                  <p className="text-sm">
                    "Amazing IQ testing platform! The chambers are challenging
                    and the real-time scoring keeps me engaged. Perfect for
                    brain training."
                  </p>
                </div>

                <div className="bg-secondary/10 rounded-lg p-6 glass-effect">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <svg
                          key={star}
                          className="w-4 h-4 text-yellow-400 fill-yellow-400"
                          viewBox="0 0 24 24"
                        >
                          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                        </svg>
                      ))}
                    </div>
                    <span className="text-sm text-muted-foreground">
                      Alex K.
                    </span>
                  </div>
                  <p className="text-sm">
                    "The Memory Core and Speed Zone are incredibly addictive!
                    Great way to challenge yourself and track improvement over
                    time."
                  </p>
                </div>

                <div className="bg-secondary/10 rounded-lg p-6 glass-effect">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex">
                      {[1, 2, 3, 4].map((star) => (
                        <svg
                          key={star}
                          className="w-4 h-4 text-yellow-400 fill-yellow-400"
                          viewBox="0 0 24 24"
                        >
                          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                        </svg>
                      ))}
                      <svg
                        className="w-4 h-4 text-muted-foreground"
                        viewBox="0 0 24 24"
                      >
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                      </svg>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      Mike R.
                    </span>
                  </div>
                  <p className="text-sm">
                    "Solid IQ testing experience. The Pattern Vault really tests
                    your cognitive abilities. Would love to see more puzzle
                    types added!"
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center border-t border-border/50 pt-12">
            <div>
              <div className="text-3xl font-bold text-neon-cyan mb-2">6</div>
              <div className="text-sm text-muted-foreground">
                Testing Chambers
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-neon-purple mb-2">83</div>
              <div className="text-sm text-muted-foreground">
                Unique Puzzles
              </div>
            </div>
            <div>
              <div className="text-3xl font-bold text-neon-green mb-2">
                4.2★
              </div>
              <div className="text-sm text-muted-foreground">Player Rating</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-neon-orange mb-2">
                Real-time
              </div>
              <div className="text-sm text-muted-foreground">Scoring</div>
            </div>
          </div>
        </div>
      </div>

      {/* Authentication Modals */}
      <AuthModals
        loginOpen={loginModalOpen}
        signupOpen={signupModalOpen}
        onLoginClose={() => setLoginModalOpen(false)}
        onSignupClose={() => setSignupModalOpen(false)}
        onSwitchToSignup={handleSwitchToSignup}
        onSwitchToLogin={handleSwitchToLogin}
      />
    </div>
  );
}
