import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Progress } from '../components/ui/progress';
import { Brain, ArrowLeft, Clock, Zap, CheckCircle, XCircle, Eye, EyeOff } from 'lucide-react';

interface Puzzle {
  id: number;
  question: string;
  type: 'sequence' | 'visual' | 'words' | 'numbers';
  memoryTime: number;
  answerTime: number;
  sequence?: string[] | number[];
  options: string[];
  correct: number;
  difficulty: 'easy' | 'medium' | 'hard' | 'expert';
  points: number;
}

const puzzles: Puzzle[] = [
  {
    id: 1,
    question: "Remember this sequence of numbers:",
    type: 'numbers',
    memoryTime: 3000,
    answerTime: 15000,
    sequence: [7, 3, 9, 1, 5],
    options: ["7, 3, 9, 1, 5", "7, 3, 9, 5, 1", "3, 7, 9, 1, 5", "7, 9, 3, 1, 5"],
    correct: 0,
    difficulty: 'easy',
    points: 5
  },
  {
    id: 2,
    question: "What was the THIRD word in this sequence?",
    type: 'words',
    memoryTime: 4000,
    answerTime: 15000,
    sequence: ["APPLE", "MOUNTAIN", "CLOCK", "RIVER", "PENCIL"],
    options: ["APPLE", "MOUNTAIN", "CLOCK", "RIVER"],
    correct: 2,
    difficulty: 'easy',
    points: 5
  },
  {
    id: 3,
    question: "Repeat this number sequence in REVERSE order:",
    type: 'numbers',
    memoryTime: 5000,
    answerTime: 20000,
    sequence: [4, 8, 2, 6, 3, 9],
    options: ["9, 3, 6, 2, 8, 4", "4, 8, 2, 6, 3, 9", "9, 6, 3, 2, 8, 4", "3, 9, 6, 2, 8, 4"],
    correct: 0,
    difficulty: 'easy',
    points: 5
  },
  {
    id: 4,
    question: "Which color appeared SECOND in this sequence?",
    type: 'words',
    memoryTime: 4000,
    answerTime: 15000,
    sequence: ["RED", "BLUE", "GREEN", "YELLOW", "PURPLE", "ORANGE"],
    options: ["RED", "BLUE", "GREEN", "YELLOW"],
    correct: 1,
    difficulty: 'medium',
    points: 10
  },
  {
    id: 5,
    question: "What is the SUM of all the numbers shown?",
    type: 'numbers',
    memoryTime: 6000,
    answerTime: 25000,
    sequence: [13, 7, 21, 8, 15],
    options: ["62", "64", "66", "68"],
    correct: 1,
    difficulty: 'medium',
    points: 10
  },
  {
    id: 6,
    question: "Which word was NOT in the sequence?",
    type: 'words',
    memoryTime: 5000,
    answerTime: 20000,
    sequence: ["TELESCOPE", "BUTTERFLY", "KEYBOARD", "ELEPHANT", "GUITAR"],
    options: ["TELESCOPE", "BUTTERFLY", "MICROSCOPE", "ELEPHANT"],
    correct: 2,
    difficulty: 'medium',
    points: 10
  },
  {
    id: 7,
    question: "Memorize and recall this complex sequence:",
    type: 'sequence',
    memoryTime: 8000,
    answerTime: 30000,
    sequence: ["A3", "B7", "C1", "D9", "E4", "F6"],
    options: ["A3, B7, C1, D9, E4, F6", "A3, B7, C1, D9, F6, E4", "A3, C1, B7, D9, E4, F6", "B7, A3, C1, D9, E4, F6"],
    correct: 0,
    difficulty: 'hard',
    points: 15
  },
  {
    id: 8,
    question: "What was the PRODUCT of the first and last numbers?",
    type: 'numbers',
    memoryTime: 6000,
    answerTime: 25000,
    sequence: [12, 7, 3, 9, 4],
    options: ["36", "48", "52", "64"],
    correct: 1,
    difficulty: 'hard',
    points: 15
  },
  {
    id: 9,
    question: "Recall this sequence in alphabetical order:",
    type: 'words',
    memoryTime: 7000,
    answerTime: 30000,
    sequence: ["ZEBRA", "APPLE", "QUEEN", "HOUSE", "DANCE"],
    options: ["APPLE, DANCE, HOUSE, QUEEN, ZEBRA", "APPLE, DANCE, QUEEN, HOUSE, ZEBRA", "DANCE, APPLE, HOUSE, QUEEN, ZEBRA", "APPLE, HOUSE, DANCE, QUEEN, ZEBRA"],
    correct: 0,
    difficulty: 'hard',
    points: 15
  },
  {
    id: 10,
    question: "Complex pattern - memorize and repeat exactly:",
    type: 'sequence',
    memoryTime: 10000,
    answerTime: 40000,
    sequence: ["X7Y", "Z3A", "B9C", "D1E", "F5G", "H8I", "J2K"],
    options: [
      "X7Y, Z3A, B9C, D1E, F5G, H8I, J2K",
      "X7Y, Z3A, B9C, D1E, F5G, J2K, H8I",
      "X7Y, A3Z, B9C, D1E, F5G, H8I, J2K",
      "X7Y, Z3A, C9B, D1E, F5G, H8I, J2K"
    ],
    correct: 0,
    difficulty: 'expert',
    points: 20
  },
  {
    id: 11,
    question: "Calculate: What's the average of these numbers?",
    type: 'numbers',
    memoryTime: 8000,
    answerTime: 35000,
    sequence: [17, 23, 11, 29, 15, 31, 19],
    options: ["19", "20", "21", "22"],
    correct: 2,
    difficulty: 'expert',
    points: 20
  },
  {
    id: 12,
    question: "Master challenge - recall this sequence backwards:",
    type: 'sequence',
    memoryTime: 12000,
    answerTime: 45000,
    sequence: ["Q8W", "E2R", "T6Y", "U1I", "O9P", "A4S", "D7F"],
    options: [
      "D7F, A4S, O9P, U1I, T6Y, E2R, Q8W",
      "D7F, A4S, O9P, I1U, T6Y, E2R, Q8W",
      "F7D, A4S, O9P, U1I, T6Y, E2R, Q8W",
      "D7F, S4A, O9P, U1I, T6Y, E2R, Q8W"
    ],
    correct: 0,
    difficulty: 'expert',
    points: 20
  }
];

export default function MemoryCore() {
  const navigate = useNavigate();
  const [currentPuzzle, setCurrentPuzzle] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [gameStarted, setGameStarted] = useState(false);
  const [gamePhase, setGamePhase] = useState<'memorize' | 'answer'>('memorize');
  const [timeLeft, setTimeLeft] = useState(0);
  const [showSequence, setShowSequence] = useState(true);

  const puzzle = puzzles[currentPuzzle] || puzzles[0];

  useEffect(() => {
    if (!gameStarted || !puzzle) return;

    if (gamePhase === 'memorize') {
      setTimeLeft(puzzle.memoryTime / 1000);
      setShowSequence(true);
    } else {
      setTimeLeft(puzzle.answerTime / 1000);
      setShowSequence(false);
    }
  }, [currentPuzzle, gamePhase, gameStarted]);

  useEffect(() => {
    if (!gameStarted || timeLeft <= 0) return;
    
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          if (gamePhase === 'memorize') {
            setGamePhase('answer');
            return puzzle.answerTime / 1000;
          } else {
            handleTimeUp();
            return 0;
          }
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, gamePhase, gameStarted, puzzle]);

  const handleTimeUp = () => {
    setShowResult(true);
    setIsCorrect(false);
    setTimeout(() => nextPuzzle(), 2000);
  };

  const handleAnswer = (answerIndex: number) => {
    if (showResult || gamePhase === 'memorize') return;
    
    setSelectedAnswer(answerIndex);
    const correct = answerIndex === puzzle.correct;
    
    setIsCorrect(correct);
    setShowResult(true);
    
    if (correct) {
      const speedBonus = Math.floor((timeLeft / (puzzle.answerTime / 1000)) * 5);
      setScore(prev => prev + puzzle.points + speedBonus);
    }
    
    setTimeout(() => nextPuzzle(), 2000);
  };

  const nextPuzzle = () => {
    if (currentPuzzle < puzzles.length - 1) {
      setCurrentPuzzle(prev => prev + 1);
      setSelectedAnswer(null);
      setShowResult(false);
      setIsCorrect(null);
      setGamePhase('memorize');
    } else {
      navigate('/results', { state: { score, totalPossible: puzzles.reduce((sum, p) => sum + p.points + 5, 0), chamber: 'Memory Core' } });
    }
  };

  const startGame = () => {
    setGameStarted(true);
    setGamePhase('memorize');
  };

  const progress = ((currentPuzzle + (showResult ? 1 : 0)) / puzzles.length) * 100;

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="absolute inset-0 grid-pattern opacity-20" />
        
        <Card className="max-w-2xl w-full mx-4 glass-effect border-neon-green/50">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-neon-green/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Brain className="w-8 h-8 text-neon-green" />
            </div>
            <CardTitle className="text-2xl text-neon-green">Memory Core</CardTitle>
            <p className="text-muted-foreground">Challenge your short and long-term memory</p>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-4">Challenge Details</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Memory Tasks</div>
                  <div className="text-muted-foreground">{puzzles.length} Challenges</div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Difficulty</div>
                  <div className="text-muted-foreground">Escalating</div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Memory Time</div>
                  <div className="text-muted-foreground">3-12s to memorize</div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Answer Time</div>
                  <div className="text-muted-foreground">15-45s to recall</div>
                </div>
              </div>
            </div>
            
            <div className="flex gap-4">
              <Button variant="outline" asChild className="flex-1">
                <Link to="/game">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Lobby
                </Link>
              </Button>
              <Button onClick={startGame} className="flex-1 animate-pulse-glow bg-neon-green hover:bg-neon-green/90">
                Start Challenge
                <Zap className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="absolute inset-0 grid-pattern opacity-20" />
      
      <div className="relative container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-neon-green/20 rounded-lg flex items-center justify-center">
              <Brain className="w-4 h-4 text-neon-green" />
            </div>
            <span className="text-lg font-bold text-neon-green">Memory Core</span>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Score</div>
              <div className="text-lg font-bold text-neon-green">{score}</div>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted-foreground">
                {gamePhase === 'memorize' ? 'Memorize' : 'Recall'}
              </div>
              <div className={`text-lg font-bold ${timeLeft <= 5 ? 'text-destructive' : 'text-neon-orange'}`}>
                {timeLeft}s
              </div>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <div className="flex justify-between text-sm mb-2">
            <span>Challenge {currentPuzzle + 1} of {puzzles.length}</span>
            <span>{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="glass-effect border-border/50 mb-8">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    puzzle.difficulty === 'easy' ? 'bg-green-500/20 text-green-400' :
                    puzzle.difficulty === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                    puzzle.difficulty === 'hard' ? 'bg-orange-500/20 text-orange-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {puzzle.difficulty.toUpperCase()}
                  </span>
                  <span className="text-sm text-muted-foreground">{puzzle.points} points</span>
                </div>
                <div className="flex items-center gap-2">
                  {showSequence ? <Eye className="w-4 h-4 text-neon-green" /> : <EyeOff className="w-4 h-4 text-muted-foreground" />}
                  <Clock className="w-4 h-4 text-muted-foreground" />
                </div>
              </div>
              <CardTitle className="text-xl leading-relaxed">{puzzle.question}</CardTitle>
            </CardHeader>
            
            <CardContent>
              {gamePhase === 'memorize' && showSequence && (
                <div className="text-center py-8">
                  <div className="text-3xl font-bold text-neon-green font-mono mb-4">
                    {Array.isArray(puzzle.sequence) && puzzle.sequence.join(puzzle.type === 'numbers' || puzzle.type === 'sequence' ? ', ' : ' → ')}
                  </div>
                  <p className="text-muted-foreground">Memorize this sequence carefully...</p>
                </div>
              )}
              
              {gamePhase === 'answer' && !showResult && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {puzzle.options.map((option, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className={`p-6 h-auto text-left justify-start transition-all duration-300 font-mono ${
                        selectedAnswer === index
                          ? 'border-neon-green bg-neon-green/10'
                          : 'border-border hover:border-neon-green/50'
                      } cursor-pointer hover:scale-[1.02]`}
                      onClick={() => handleAnswer(index)}
                    >
                      <div className="flex items-center gap-3">
                        <span className="flex items-center justify-center w-6 h-6 rounded-full bg-secondary text-sm font-medium">
                          {String.fromCharCode(65 + index)}
                        </span>
                        <span className="flex-1">{option}</span>
                      </div>
                    </Button>
                  ))}
                </div>
              )}
              
              {showResult && (
                <div className="text-center py-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    {puzzle.options.map((option, index) => (
                      <div
                        key={index}
                        className={`p-4 rounded-lg border-2 ${
                          index === puzzle.correct
                            ? 'border-neon-green bg-neon-green/10 text-neon-green'
                            : selectedAnswer === index && index !== puzzle.correct
                            ? 'border-destructive bg-destructive/10 text-destructive'
                            : 'border-border'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span className="flex items-center justify-center w-6 h-6 rounded-full bg-secondary text-sm font-medium">
                            {String.fromCharCode(65 + index)}
                          </span>
                          <span className="flex-1 font-mono">{option}</span>
                          {index === puzzle.correct && (
                            <CheckCircle className="w-5 h-5 text-neon-green" />
                          )}
                          {selectedAnswer === index && index !== puzzle.correct && (
                            <XCircle className="w-5 h-5 text-destructive" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className={`text-lg font-semibold ${isCorrect ? 'text-neon-green' : 'text-destructive'}`}>
                    {isCorrect ? 'Memory Intact!' : 'Memory Lapse'}
                  </div>
                  {isCorrect && (
                    <div className="text-sm text-muted-foreground mt-1">
                      +{puzzle.points + Math.floor((timeLeft / (puzzle.answerTime / 1000)) * 5)} points
                      {timeLeft > (puzzle.answerTime / 1000) * 0.5 && (
                        <span className="text-neon-orange ml-1">(Quick Recall!)</span>
                      )}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
