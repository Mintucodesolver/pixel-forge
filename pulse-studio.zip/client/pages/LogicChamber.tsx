import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Progress } from "../components/ui/progress";
import {
  Brain,
  ArrowLeft,
  Clock,
  Zap,
  CheckCircle,
  XCircle,
} from "lucide-react";

interface Puzzle {
  id: number;
  question: string;
  options: string[];
  correct: number;
  difficulty: "easy" | "medium" | "hard" | "expert";
  timeLimit: number;
  points: number;
}

const puzzles: Puzzle[] = [
  {
    id: 1,
    question: "What comes next in the sequence: 2, 4, 6, ?",
    options: ["7", "8", "9", "10"],
    correct: 1,
    difficulty: "easy",
    timeLimit: 30,
    points: 5,
  },
  {
    id: 2,
    question: "Which number doesn't belong: 2, 4, 6, 9, 8?",
    options: ["2", "4", "9", "8"],
    correct: 2,
    difficulty: "easy",
    timeLimit: 30,
    points: 5,
  },
  {
    id: 3,
    question: "If you have 3 apples and you take away 2, how many do you have?",
    options: ["1", "2", "3", "5"],
    correct: 1,
    difficulty: "easy",
    timeLimit: 30,
    points: 5,
  },
  {
    id: 4,
    question: "If DOG = 26, CAT = 24, what is LION?",
    options: ["45", "48", "52", "56"],
    correct: 2,
    difficulty: "medium",
    timeLimit: 40,
    points: 10,
  },
  {
    id: 5,
    question: "Find the missing number: 1, 1, 2, 3, 5, 8, ?",
    options: ["11", "13", "15", "17"],
    correct: 1,
    difficulty: "medium",
    timeLimit: 40,
    points: 10,
  },
  {
    id: 6,
    question:
      "If it takes 5 machines 5 minutes to make 5 widgets, how long would it take 100 machines to make 100 widgets?",
    options: ["5 minutes", "20 minutes", "100 minutes", "500 minutes"],
    correct: 0,
    difficulty: "medium",
    timeLimit: 40,
    points: 10,
  },
  {
    id: 7,
    question:
      "A man lives on the 20th floor of an apartment building. Every morning he takes the elevator down to the ground floor. When he comes home, he takes the elevator to the 10th floor and walks the rest of the way... except on rainy days, when he takes the elevator all the way to the 20th floor. Why?",
    options: [
      "He's afraid of heights",
      "He's short and can't reach the 20th floor button unless he has an umbrella",
      "He likes exercise",
      "The elevator is broken",
    ],
    correct: 1,
    difficulty: "hard",
    timeLimit: 50,
    points: 15,
  },
  {
    id: 8,
    question:
      "If all Bloops are Razzles and all Razzles are Lazzles, then all Bloops are definitely Lazzles?",
    options: ["True", "False", "Cannot be determined", "Sometimes"],
    correct: 0,
    difficulty: "hard",
    timeLimit: 50,
    points: 15,
  },
  {
    id: 9,
    question:
      "In a certain code, MONDAY is written as NOEBZF. How would FRIDAY be written?",
    options: ["GSJECF", "GSJEDF", "GSJEBZ", "GSEBZF"],
    correct: 0,
    difficulty: "hard",
    timeLimit: 50,
    points: 15,
  },
  {
    id: 10,
    question:
      "A father is 4 times as old as his son. In 20 years, he will be only twice as old. How old is the son now?",
    options: ["10 years", "15 years", "20 years", "25 years"],
    correct: 0,
    difficulty: "expert",
    timeLimit: 60,
    points: 20,
  },
  {
    id: 11,
    question:
      "You have 12 balls that look identical. 11 weigh the same, but one is either heavier or lighter. Using a balance scale only 3 times, how do you find the different ball?",
    options: [
      "Divide into groups of 4-4-4",
      "Divide into groups of 6-6",
      "Divide into groups of 3-3-6",
      "It's impossible with 3 weighings",
    ],
    correct: 0,
    difficulty: "expert",
    timeLimit: 60,
    points: 20,
  },
  {
    id: 12,
    question:
      "If you write down all the numbers from 1 to 100, how many times will you write the digit 9?",
    options: ["10", "19", "20", "21"],
    correct: 2,
    difficulty: "expert",
    timeLimit: 60,
    points: 20,
  },
];

export default function LogicChamber() {
  const navigate = useNavigate();
  const [currentPuzzle, setCurrentPuzzle] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(puzzles[0]?.timeLimit || 30);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [gameStarted, setGameStarted] = useState(false);

  useEffect(() => {
    if (!gameStarted) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentPuzzle, gameStarted]);

  const handleTimeUp = () => {
    setShowResult(true);
    setIsCorrect(false);
    setTimeout(() => nextPuzzle(), 2000);
  };

  const handleAnswer = (answerIndex: number) => {
    if (showResult) return;

    setSelectedAnswer(answerIndex);
    const currentPuzzleData = puzzles[currentPuzzle];
    if (!currentPuzzleData) return;

    const correct = answerIndex === currentPuzzleData.correct;

    setIsCorrect(correct);
    setShowResult(true);

    if (correct) {
      const speedBonus = Math.floor(
        (timeLeft / currentPuzzleData.timeLimit) * 5,
      );
      setScore((prev) => prev + currentPuzzleData.points + speedBonus);
    }

    setTimeout(() => nextPuzzle(), 2000);
  };

  const nextPuzzle = () => {
    if (currentPuzzle < puzzles.length - 1) {
      setCurrentPuzzle((prev) => prev + 1);
      setSelectedAnswer(null);
      setShowResult(false);
      setIsCorrect(null);
      const nextPuzzle = puzzles[currentPuzzle + 1];
      setTimeLeft(nextPuzzle?.timeLimit || 30);
    } else {
      // Game finished - navigate to results
      navigate("/results", {
        state: {
          score,
          totalPossible: puzzles.reduce(
            (sum, p) => sum + (p?.points || 0) + 5,
            0,
          ),
        },
      });
    }
  };

  const startGame = () => {
    setGameStarted(true);
    setTimeLeft(puzzles[0]?.timeLimit || 30);
  };

  const puzzle = puzzles[currentPuzzle] || puzzles[0];
  const progress =
    puzzles.length > 0
      ? ((currentPuzzle + (showResult ? 1 : 0)) / puzzles.length) * 100
      : 0;

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="absolute inset-0 grid-pattern opacity-20" />

        <Card className="max-w-2xl w-full mx-4 glass-effect border-neon-cyan/50">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-neon-cyan/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Brain className="w-8 h-8 text-neon-cyan" />
            </div>
            <CardTitle className="text-2xl text-neon-cyan">
              Logic Chamber
            </CardTitle>
            <p className="text-muted-foreground">
              Test your reasoning and problem-solving abilities
            </p>
          </CardHeader>

          <CardContent className="space-y-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-4">Challenge Details</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Puzzles</div>
                  <div className="text-muted-foreground">
                    {puzzles.length} Questions
                  </div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Difficulty</div>
                  <div className="text-muted-foreground">Progressive</div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Time Limit</div>
                  <div className="text-muted-foreground">30-50s each</div>
                </div>
                <div className="bg-secondary/20 rounded-lg p-3">
                  <div className="font-semibold">Scoring</div>
                  <div className="text-muted-foreground">Speed + Accuracy</div>
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <Button variant="outline" asChild className="flex-1">
                <Link to="/game">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Lobby
                </Link>
              </Button>
              <Button onClick={startGame} className="flex-1 animate-pulse-glow">
                Start Challenge
                <Zap className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="absolute inset-0 grid-pattern opacity-20" />

      <div className="relative container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-neon-cyan/20 rounded-lg flex items-center justify-center">
              <Brain className="w-4 h-4 text-neon-cyan" />
            </div>
            <span className="text-lg font-bold text-neon-cyan">
              Logic Chamber
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Score</div>
              <div className="text-lg font-bold text-neon-cyan">{score}</div>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Time</div>
              <div
                className={`text-lg font-bold ${timeLeft <= 10 ? "text-destructive" : "text-neon-orange"}`}
              >
                {timeLeft}s
              </div>
            </div>
          </div>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between text-sm mb-2">
            <span>
              Question {currentPuzzle + 1} of {puzzles.length}
            </span>
            <span>{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Puzzle */}
        <div className="max-w-4xl mx-auto">
          <Card className="glass-effect border-border/50 mb-8">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2 py-1 rounded text-xs font-medium ${
                      (puzzle?.difficulty || "easy") === "easy"
                        ? "bg-green-500/20 text-green-400"
                        : (puzzle?.difficulty || "easy") === "medium"
                          ? "bg-yellow-500/20 text-yellow-400"
                          : (puzzle?.difficulty || "easy") === "hard"
                            ? "bg-orange-500/20 text-orange-400"
                            : "bg-red-500/20 text-red-400"
                    }`}
                  >
                    {(puzzle?.difficulty || "easy").toUpperCase()}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {puzzle?.points || 0} points
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">
                    {puzzle?.timeLimit || 30}s
                  </span>
                </div>
              </div>
              <CardTitle className="text-xl leading-relaxed">
                {puzzle?.question || "Loading..."}
              </CardTitle>
            </CardHeader>

            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(puzzle?.options || []).map((option, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className={`p-6 h-auto text-left justify-start transition-all duration-300 ${
                      showResult && index === (puzzle?.correct || 0)
                        ? "border-neon-green bg-neon-green/10 text-neon-green"
                        : showResult &&
                            selectedAnswer === index &&
                            index !== (puzzle?.correct || 0)
                          ? "border-destructive bg-destructive/10 text-destructive"
                          : selectedAnswer === index
                            ? "border-neon-cyan bg-neon-cyan/10"
                            : "border-border hover:border-neon-cyan/50"
                    } ${showResult ? "cursor-default" : "cursor-pointer hover:scale-[1.02]"}`}
                    onClick={() => handleAnswer(index)}
                    disabled={showResult}
                  >
                    <div className="flex items-center gap-3">
                      <span className="flex items-center justify-center w-6 h-6 rounded-full bg-secondary text-sm font-medium">
                        {String.fromCharCode(65 + index)}
                      </span>
                      <span className="flex-1">{option}</span>
                      {showResult && index === (puzzle?.correct || 0) && (
                        <CheckCircle className="w-5 h-5 text-neon-green" />
                      )}
                      {showResult &&
                        selectedAnswer === index &&
                        index !== (puzzle?.correct || 0) && (
                          <XCircle className="w-5 h-5 text-destructive" />
                        )}
                    </div>
                  </Button>
                ))}
              </div>

              {showResult && (
                <div className="mt-6 text-center">
                  <div
                    className={`text-lg font-semibold ${isCorrect ? "text-neon-green" : "text-destructive"}`}
                  >
                    {isCorrect ? "Correct!" : "Incorrect"}
                  </div>
                  {isCorrect && (
                    <div className="text-sm text-muted-foreground mt-1">
                      +
                      {(puzzle?.points || 0) +
                        Math.floor(
                          (timeLeft / (puzzle?.timeLimit || 30)) * 5,
                        )}{" "}
                      points
                      {timeLeft > (puzzle?.timeLimit || 30) * 0.5 && (
                        <span className="text-neon-orange ml-1">
                          (Speed Bonus!)
                        </span>
                      )}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
