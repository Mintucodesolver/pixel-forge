import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { 
  Trophy, 
  Medal, 
  Crown, 
  Brain, 
  Target, 
  Zap, 
  Clock, 
  Star,
  TrendingUp,
  Calendar,
  Users,
  Award,
  Filter
} from 'lucide-react';
import Header from '../components/Header';
import { useAuth } from '../components/AuthContext';

interface LeaderboardEntry {
  id: number;
  name: string;
  avatar?: string;
  totalScore: number;
  avgIQ: number;
  gamesPlayed: number;
  bestChamber: string;
  lastPlayed: string;
  achievements: string[];
  rank: number;
  weeklyScore: number;
  monthlyScore: number;
}

// Generate sample leaderboard data
const generateLeaderboardData = (): LeaderboardEntry[] => {
  const names = [
    'Einstein_AI', 'Quantum_Mind', 'Neural_Net', 'Logic_Master', 'Pattern_Pro',
    'Memory_Bank', 'Speed_Demon', 'Brain_Storm', 'IQ_Elite', 'Genius_Code',
    'Mind_Bender', 'Puzzle_King', 'Quick_Think', 'Smart_Fox', 'Wise_Owl',
    'Clever_Cat', 'Sharp_Edge', 'Bright_Star', 'Fast_Lane', 'Deep_Think'
  ];

  const chambers = ['Logic Chamber', 'Pattern Vault', 'Memory Core', 'Speed Zone'];
  const achievements = ['First Blood', 'Speed Runner', 'Perfect Score', 'Streak Master', 'Brain Elite'];

  return names.map((name, index) => ({
    id: index + 1,
    name,
    totalScore: Math.max(200, Math.floor(Math.random() * 500) + 200),
    avgIQ: Math.max(85, Math.min(160, Math.floor(Math.random() * 40) + 100)),
    gamesPlayed: Math.max(1, Math.floor(Math.random() * 100) + 10),
    bestChamber: chambers.length > 0 ? chambers[Math.floor(Math.random() * chambers.length)] : 'Logic Chamber',
    lastPlayed: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toLocaleDateString(),
    achievements: achievements.slice(0, Math.max(1, Math.floor(Math.random() * 3) + 1)),
    rank: index + 1,
    weeklyScore: Math.max(10, Math.floor(Math.random() * 200) + 50),
    monthlyScore: Math.max(50, Math.floor(Math.random() * 800) + 150)
  })).sort((a, b) => (b.totalScore || 0) - (a.totalScore || 0));
};

export default function Leaderboard() {
  const { user } = useAuth();
  const [leaderboardData, setLeaderboardData] = useState<LeaderboardEntry[]>([]);
  const [timeFilter, setTimeFilter] = useState<'all' | 'weekly' | 'monthly'>('all');
  const [userRank, setUserRank] = useState<LeaderboardEntry | null>(null);

  useEffect(() => {
    const data = generateLeaderboardData();
    
    // Add current user to leaderboard if logged in
    if (user) {
      const userEntry: LeaderboardEntry = {
        id: user.id || Date.now(),
        name: user.name || 'Anonymous',
        totalScore: Math.max(0, (user.totalGamesPlayed || 0) * 45 + Math.floor(Math.random() * 100)),
        avgIQ: Math.max(85, Math.min(160, user.avgIQ || Math.floor(Math.random() * 20) + 105)),
        gamesPlayed: Math.max(0, user.totalGamesPlayed || 0),
        bestChamber: 'Logic Chamber',
        lastPlayed: 'Today',
        achievements: ['New Player', 'First Steps'],
        rank: 0,
        weeklyScore: Math.max(0, Math.floor(Math.random() * 150) + 30),
        monthlyScore: Math.max(0, Math.floor(Math.random() * 600) + 100)
      };
      
      data.splice(Math.floor(Math.random() * 10) + 5, 0, userEntry);
    }

    // Re-rank based on selected time filter
    const sortedData = data.sort((a, b) => {
      switch (timeFilter) {
        case 'weekly':
          return b.weeklyScore - a.weeklyScore;
        case 'monthly':
          return b.monthlyScore - a.monthlyScore;
        default:
          return b.totalScore - a.totalScore;
      }
    }).map((entry, index) => ({ ...entry, rank: index + 1 }));

    setLeaderboardData(sortedData);
    
    if (user) {
      const currentUserRank = sortedData.find(entry => entry.id === user.id);
      setUserRank(currentUserRank || null);
    }
  }, [user, timeFilter]);

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="w-5 h-5 text-yellow-400" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-gray-400" />;
    if (rank === 3) return <Medal className="w-5 h-5 text-amber-600" />;
    return <span className="text-sm font-bold text-muted-foreground">#{rank}</span>;
  };

  const getScoreForFilter = (entry: LeaderboardEntry) => {
    let score;
    switch (timeFilter) {
      case 'weekly':
        score = entry.weeklyScore;
        break;
      case 'monthly':
        score = entry.monthlyScore;
        break;
      default:
        score = entry.totalScore;
        break;
    }
    return isNaN(score) || score === undefined || score === null ? 0 : Math.max(0, score);
  };

  const getChamberIcon = (chamber: string) => {
    switch (chamber) {
      case 'Logic Chamber':
        return <Brain className="w-4 h-4 text-neon-cyan" />;
      case 'Pattern Vault':
        return <Target className="w-4 h-4 text-neon-purple" />;
      case 'Memory Core':
        return <Brain className="w-4 h-4 text-neon-green" />;
      case 'Speed Zone':
        return <Zap className="w-4 h-4 text-neon-orange" />;
      default:
        return <Brain className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="absolute inset-0 grid-pattern opacity-20" />
      
      <div className="relative container mx-auto px-4 py-8">
        <Header showProgress={false} showAuth={true} />

        {/* Page Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-yellow-400/20 rounded-lg flex items-center justify-center">
              <Trophy className="w-6 h-6 text-yellow-400" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
              Global Leaderboard
            </h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Compete with players worldwide and track your Mind Lab ranking
          </p>
        </div>

        {/* User Rank Card */}
        {userRank && (
          <Card className="max-w-4xl mx-auto mb-8 glass-effect border-yellow-400/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    {getRankIcon(userRank.rank)}
                    <span className="text-2xl font-bold">Your Rank</span>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-yellow-400">#{userRank.rank || 0}</div>
                    <div className="text-sm text-muted-foreground">
                      {getScoreForFilter(userRank) || 0} points
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <div className="text-lg font-bold">{userRank.avgIQ}</div>
                    <div className="text-xs text-muted-foreground">Avg IQ</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold">{userRank.gamesPlayed}</div>
                    <div className="text-xs text-muted-foreground">Games</div>
                  </div>
                  <Button asChild>
                    <Link to="/game">Play Now</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Time Filter Tabs */}
        <Tabs value={timeFilter} onValueChange={(value) => setTimeFilter(value as 'all' | 'weekly' | 'monthly')} className="max-w-6xl mx-auto">
          <div className="flex items-center justify-center mb-8">
            <TabsList className="grid w-full max-w-md grid-cols-3 glass-effect">
              <TabsTrigger value="all" className="flex items-center gap-2">
                <Trophy className="w-4 h-4" />
                All Time
              </TabsTrigger>
              <TabsTrigger value="monthly" className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Monthly
              </TabsTrigger>
              <TabsTrigger value="weekly" className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Weekly
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value={timeFilter} className="space-y-6">
            {/* Top 3 Podium */}
            <div className="grid md:grid-cols-3 gap-4 mb-8">
              {leaderboardData.slice(0, 3).map((entry, index) => (
                <Card key={entry.id} className={`glass-effect relative overflow-hidden ${
                  index === 0 ? 'border-yellow-400/50 md:order-2' :
                  index === 1 ? 'border-gray-400/50 md:order-1' :
                  'border-amber-600/50 md:order-3'
                }`}>
                  <div className={`absolute top-0 left-0 right-0 h-1 ${
                    index === 0 ? 'bg-yellow-400' :
                    index === 1 ? 'bg-gray-400' :
                    'bg-amber-600'
                  }`} />
                  <CardContent className="p-6 text-center">
                    <div className="mb-4">
                      {getRankIcon(entry.rank)}
                    </div>
                    <h3 className="font-bold text-lg mb-2">{entry.name}</h3>
                    <div className="text-2xl font-bold text-primary mb-1">
                      {getScoreForFilter(entry) || 0}
                    </div>
                    <div className="text-sm text-muted-foreground mb-3">points</div>
                    <div className="flex justify-center gap-4 text-xs">
                      <div>
                        <div className="font-semibold">{entry.avgIQ || 0}</div>
                        <div className="text-muted-foreground">IQ</div>
                      </div>
                      <div>
                        <div className="font-semibold">{entry.gamesPlayed || 0}</div>
                        <div className="text-muted-foreground">Games</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Full Leaderboard */}
            <Card className="glass-effect border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Rankings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {leaderboardData.map((entry, index) => (
                    <div
                      key={entry.id}
                      className={`flex items-center justify-between p-4 rounded-lg transition-all hover:bg-secondary/20 ${
                        user && entry.id === user.id ? 'bg-primary/10 border border-primary/20' : 'bg-secondary/5'
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-8 flex justify-center">
                          {getRankIcon(entry.rank)}
                        </div>
                        
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold">{entry.name}</span>
                            {user && entry.id === user.id && (
                              <Badge variant="outline" className="text-xs">You</Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              {getChamberIcon(entry.bestChamber)}
                              Best: {entry.bestChamber}
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {entry.lastPlayed}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <div className="font-bold text-lg">{getScoreForFilter(entry) || 0}</div>
                          <div className="text-sm text-muted-foreground">points</div>
                        </div>

                        <div className="text-right">
                          <div className="font-semibold">{entry.avgIQ || 0}</div>
                          <div className="text-sm text-muted-foreground">IQ</div>
                        </div>

                        <div className="text-right">
                          <div className="font-semibold">{entry.gamesPlayed || 0}</div>
                          <div className="text-sm text-muted-foreground">games</div>
                        </div>

                        <div className="flex gap-1">
                          {entry.achievements.slice(0, 2).map((achievement, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              <Award className="w-3 h-3 mr-1" />
                              {achievement}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Statistics */}
            <div className="grid md:grid-cols-4 gap-4">
              <Card className="glass-effect border-border/50">
                <CardContent className="p-4 text-center">
                  <Users className="w-8 h-8 mx-auto mb-2 text-neon-cyan" />
                  <div className="text-2xl font-bold">{leaderboardData.length}</div>
                  <div className="text-sm text-muted-foreground">Active Players</div>
                </CardContent>
              </Card>
              
              <Card className="glass-effect border-border/50">
                <CardContent className="p-4 text-center">
                  <Brain className="w-8 h-8 mx-auto mb-2 text-neon-purple" />
                  <div className="text-2xl font-bold">
                    {leaderboardData.length > 0
                      ? Math.round(leaderboardData.reduce((sum, p) => sum + (p.avgIQ || 0), 0) / leaderboardData.length)
                      : 0}
                  </div>
                  <div className="text-sm text-muted-foreground">Avg IQ</div>
                </CardContent>
              </Card>
              
              <Card className="glass-effect border-border/50">
                <CardContent className="p-4 text-center">
                  <Star className="w-8 h-8 mx-auto mb-2 text-yellow-400" />
                  <div className="text-2xl font-bold">
                    {leaderboardData.length > 0
                      ? Math.max(...leaderboardData.map(p => getScoreForFilter(p) || 0))
                      : 0}
                  </div>
                  <div className="text-sm text-muted-foreground">High Score</div>
                </CardContent>
              </Card>

              <Card className="glass-effect border-border/50">
                <CardContent className="p-4 text-center">
                  <TrendingUp className="w-8 h-8 mx-auto mb-2 text-neon-green" />
                  <div className="text-2xl font-bold">
                    {leaderboardData.reduce((sum, p) => sum + (p.gamesPlayed || 0), 0)}
                  </div>
                  <div className="text-sm text-muted-foreground">Total Games</div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
