import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import {
  Brain,
  LogIn,
  UserPlus,
  Eye,
  EyeOff,
  Mail,
  Lock,
  User,
  Check,
} from "lucide-react";
import { useAuth } from "./AuthContext";

interface AuthModalsProps {
  loginOpen: boolean;
  signupOpen: boolean;
  onLoginClose: () => void;
  onSignupClose: () => void;
  onSwitchToSignup: () => void;
  onSwitchToLogin: () => void;
}

export default function AuthModals({
  loginOpen,
  signupOpen,
  onLoginClose,
  onSignupClose,
  onSwitchToSignup,
  onSwitchToLogin,
}: AuthModalsProps) {
  const navigate = useNavigate();
  const { login } = useAuth();

  // Login form state
  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  });
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState("");

  // Signup form state
  const [signupData, setSignupData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [showSignupConfirmPassword, setShowSignupConfirmPassword] =
    useState(false);
  const [signupLoading, setSignupLoading] = useState(false);
  const [signupError, setSignupError] = useState("");
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  // Login handlers
  const handleLoginInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setLoginData((prev) => ({ ...prev, [name]: value }));
    setLoginError("");
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginLoading(true);
    setLoginError("");

    try {
      if (!loginData.email || !loginData.password) {
        setLoginError("Please fill in all fields");
        return;
      }

      if (!loginData.email.includes("@")) {
        setLoginError("Please enter a valid email address");
        return;
      }

      await new Promise((resolve) => setTimeout(resolve, 1000));

      const userData = {
        id: Date.now(),
        email: loginData.email,
        name: loginData.email.split("@")[0],
        loginTime: new Date().toISOString(),
        totalGamesPlayed: Math.floor(Math.random() * 50),
        avgIQ: Math.floor(Math.random() * 40) + 85,
      };

      localStorage.setItem("mindlab-auth-token", "demo-token-" + Date.now());
      login(userData);
      onLoginClose();
      navigate("/game");
    } catch (err) {
      setLoginError("Login failed. Please try again.");
    } finally {
      setLoginLoading(false);
    }
  };

  // Signup handlers
  const handleSignupInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setSignupData((prev) => ({ ...prev, [name]: value }));
    setSignupError("");
  };

  const validateSignupForm = () => {
    if (!signupData.name.trim()) {
      return "Please enter your name";
    }
    if (!signupData.email || !signupData.email.includes("@")) {
      return "Please enter a valid email address";
    }
    if (signupData.password.length < 6) {
      return "Password must be at least 6 characters long";
    }
    if (signupData.password !== signupData.confirmPassword) {
      return "Passwords do not match";
    }
    if (!agreedToTerms) {
      return "Please agree to the Terms of Service";
    }
    return null;
  };

  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSignupLoading(true);
    setSignupError("");

    const validationError = validateSignupForm();
    if (validationError) {
      setSignupError(validationError);
      setSignupLoading(false);
      return;
    }

    try {
      await new Promise((resolve) => setTimeout(resolve, 1500));

      const userData = {
        id: Date.now(),
        name: signupData.name,
        email: signupData.email,
        joinDate: new Date().toISOString(),
        totalGamesPlayed: 0,
        avgIQ: 0,
        achievements: [],
      };

      localStorage.setItem("mindlab-auth-token", "demo-token-" + Date.now());
      login(userData);
      onSignupClose();
      navigate("/game");
    } catch (err) {
      setSignupError("Registration failed. Please try again.");
    } finally {
      setSignupLoading(false);
    }
  };

  const getPasswordStrength = (password: string) => {
    if (password.length === 0) return { strength: 0, text: "" };
    if (password.length < 4)
      return { strength: 25, text: "Weak", color: "bg-red-500" };
    if (password.length < 6)
      return { strength: 50, text: "Fair", color: "bg-yellow-500" };
    if (password.length < 8)
      return { strength: 75, text: "Good", color: "bg-blue-500" };
    return { strength: 100, text: "Strong", color: "bg-green-500" };
  };

  const passwordStrength = getPasswordStrength(signupData.password);

  return (
    <>
      {/* Login Modal */}
      <Dialog open={loginOpen} onOpenChange={onLoginClose}>
        <DialogContent className="glass-effect border-border/50 max-w-md w-[95vw] sm:w-full">
          <DialogHeader className="text-center">
            <div className="w-16 h-16 bg-neon-cyan/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <LogIn className="w-8 h-8 text-neon-cyan" />
            </div>
            <DialogTitle className="text-2xl text-neon-cyan">
              Welcome Back
            </DialogTitle>
            <DialogDescription>
              Sign in to continue your IQ journey
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            {/* Email Field */}
            <div className="space-y-2">
              <label htmlFor="login-email" className="text-sm font-medium">
                Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  id="login-email"
                  name="email"
                  type="email"
                  value={loginData.email}
                  onChange={handleLoginInputChange}
                  placeholder="Enter your email"
                  className="w-full pl-10 pr-4 py-3 bg-secondary/20 border border-border/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-neon-cyan/50 focus:border-neon-cyan/50 transition-all"
                />
              </div>
            </div>

            {/* Password Field */}
            <div className="space-y-2">
              <label htmlFor="login-password" className="text-sm font-medium">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  id="login-password"
                  name="password"
                  type={showLoginPassword ? "text" : "password"}
                  value={loginData.password}
                  onChange={handleLoginInputChange}
                  placeholder="Enter your password"
                  className="w-full pl-10 pr-12 py-3 bg-secondary/20 border border-border/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-neon-cyan/50 focus:border-neon-cyan/50 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowLoginPassword(!showLoginPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showLoginPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Error Message */}
            {loginError && (
              <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
                <p className="text-sm text-destructive">{loginError}</p>
              </div>
            )}

            {/* Login Button */}
            <Button
              type="submit"
              className="w-full animate-pulse-glow bg-neon-cyan hover:bg-neon-cyan/90"
              disabled={loginLoading}
            >
              {loginLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  Signing in...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <LogIn className="w-4 h-4" />
                  Sign In
                </div>
              )}
            </Button>

            {/* Switch to Signup */}
            <div className="text-center border-t border-border/50 pt-4">
              <p className="text-sm text-muted-foreground mb-2">
                Don't have an account?
              </p>
              <Button
                type="button"
                variant="outline"
                onClick={onSwitchToSignup}
                className="glass-effect"
              >
                Create Account
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Signup Modal */}
      <Dialog open={signupOpen} onOpenChange={onSignupClose}>
        <DialogContent className="glass-effect border-border/50 max-w-md w-[95vw] sm:w-full max-h-[90vh] overflow-y-auto">
          <DialogHeader className="text-center">
            <div className="w-16 h-16 bg-neon-green/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <UserPlus className="w-8 h-8 text-neon-green" />
            </div>
            <DialogTitle className="text-2xl text-neon-green">
              Join Mind Lab
            </DialogTitle>
            <DialogDescription>Start your IQ journey today</DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSignupSubmit} className="space-y-4">
            {/* Name Field */}
            <div className="space-y-2">
              <label htmlFor="signup-name" className="text-sm font-medium">
                Full Name
              </label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  id="signup-name"
                  name="name"
                  type="text"
                  value={signupData.name}
                  onChange={handleSignupInputChange}
                  placeholder="Enter your full name"
                  className="w-full pl-10 pr-4 py-3 bg-secondary/20 border border-border/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-neon-green/50 focus:border-neon-green/50 transition-all"
                />
              </div>
            </div>

            {/* Email Field */}
            <div className="space-y-2">
              <label htmlFor="signup-email" className="text-sm font-medium">
                Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  id="signup-email"
                  name="email"
                  type="email"
                  value={signupData.email}
                  onChange={handleSignupInputChange}
                  placeholder="Enter your email"
                  className="w-full pl-10 pr-4 py-3 bg-secondary/20 border border-border/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-neon-green/50 focus:border-neon-green/50 transition-all"
                />
              </div>
            </div>

            {/* Password Field */}
            <div className="space-y-2">
              <label htmlFor="signup-password" className="text-sm font-medium">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  id="signup-password"
                  name="password"
                  type={showSignupPassword ? "text" : "password"}
                  value={signupData.password}
                  onChange={handleSignupInputChange}
                  placeholder="Create a password"
                  className="w-full pl-10 pr-12 py-3 bg-secondary/20 border border-border/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-neon-green/50 focus:border-neon-green/50 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowSignupPassword(!showSignupPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showSignupPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>

              {/* Password Strength */}
              {signupData.password && (
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">
                      Password strength
                    </span>
                    <span
                      className={`font-medium ${passwordStrength.strength >= 75 ? "text-green-400" : passwordStrength.strength >= 50 ? "text-yellow-400" : "text-red-400"}`}
                    >
                      {passwordStrength.text}
                    </span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-1">
                    <div
                      className={`h-1 rounded-full transition-all duration-300 ${passwordStrength.color}`}
                      style={{ width: `${passwordStrength.strength}%` }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Confirm Password Field */}
            <div className="space-y-2">
              <label
                htmlFor="signup-confirm-password"
                className="text-sm font-medium"
              >
                Confirm Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  id="signup-confirm-password"
                  name="confirmPassword"
                  type={showSignupConfirmPassword ? "text" : "password"}
                  value={signupData.confirmPassword}
                  onChange={handleSignupInputChange}
                  placeholder="Confirm your password"
                  className="w-full pl-10 pr-12 py-3 bg-secondary/20 border border-border/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-neon-green/50 focus:border-neon-green/50 transition-all"
                />
                <button
                  type="button"
                  onClick={() =>
                    setShowSignupConfirmPassword(!showSignupConfirmPassword)
                  }
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showSignupConfirmPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
              {signupData.confirmPassword &&
                signupData.password === signupData.confirmPassword && (
                  <div className="flex items-center gap-1 text-xs text-green-400">
                    <Check className="w-3 h-3" />
                    Passwords match
                  </div>
                )}
            </div>

            {/* Terms Checkbox */}
            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                id="signup-terms"
                checked={agreedToTerms}
                onChange={(e) => setAgreedToTerms(e.target.checked)}
                className="mt-1 w-4 h-4 accent-neon-green"
              />
              <label
                htmlFor="signup-terms"
                className="text-sm text-muted-foreground"
              >
                I agree to the Terms of Service and Privacy Policy
              </label>
            </div>

            {/* Error Message */}
            {signupError && (
              <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
                <p className="text-sm text-destructive">{signupError}</p>
              </div>
            )}

            {/* Signup Button */}
            <Button
              type="submit"
              className="w-full animate-pulse-glow bg-neon-green hover:bg-neon-green/90"
              disabled={signupLoading}
            >
              {signupLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  Creating account...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <UserPlus className="w-4 h-4" />
                  Create Account
                </div>
              )}
            </Button>

            {/* Switch to Login */}
            <div className="text-center border-t border-border/50 pt-4">
              <p className="text-sm text-muted-foreground mb-2">
                Already have an account?
              </p>
              <Button
                type="button"
                variant="outline"
                onClick={onSwitchToLogin}
                className="glass-effect"
              >
                Sign In
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
