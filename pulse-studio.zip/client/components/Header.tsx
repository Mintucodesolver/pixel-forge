import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from './ui/button';
import { Brain, User, LogIn, LogOut, Settings } from 'lucide-react';
import { useAuth } from './AuthContext';

interface HeaderProps {
  showProgress?: boolean;
  progress?: number;
  showAuth?: boolean;
}

function AuthSection() {
  const { user, isAuthenticated, logout } = useAuth();

  if (isAuthenticated && user) {
    return (
      <div className="flex items-center gap-2">
        <div className="text-right hidden sm:block">
          <div className="text-sm font-medium">Welcome back,</div>
          <div className="text-xs text-muted-foreground">{user.name}</div>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/profile" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              <span className="hidden md:inline">Profile</span>
            </Link>
          </Button>
          <Button variant="ghost" size="sm" onClick={logout}>
            <LogOut className="w-4 h-4" />
            <span className="hidden md:inline ml-2">Logout</span>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <Link to="/login">
        <Button variant="ghost" size="sm" className="flex items-center gap-2">
          <LogIn className="w-4 h-4" />
          <span className="hidden sm:inline">Login</span>
        </Button>
      </Link>
      <Link to="/signup">
        <Button size="sm" className="animate-pulse-glow flex items-center gap-2">
          <User className="w-4 h-4" />
          <span className="hidden sm:inline">Sign Up</span>
        </Button>
      </Link>
    </div>
  );
}

export default function Header({ showProgress = false, progress = 0, showAuth = true }: HeaderProps) {
  return (
    <div className="flex items-center justify-between mb-8">
      <div className="flex items-center space-x-3">
        <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center animate-pulse-glow">
          <Brain className="w-4 h-4 text-primary-foreground" />
        </div>
        <Link to="/" className="text-xl font-bold text-neon-cyan neon-glow hover:text-neon-cyan/80 transition-colors">
          Mind Lab
        </Link>
      </div>

      <div className="flex items-center gap-4">
        {showProgress && (
          <div className="text-right">
            <div className="text-sm text-muted-foreground">Your Progress</div>
            <div className="flex items-center gap-2">
              <div className="w-24 h-2 bg-secondary rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-neon-cyan to-neon-purple transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <span className="text-sm font-medium">{progress}%</span>
            </div>
          </div>
        )}

        {showAuth && (
          <AuthSection />
        )}
      </div>
    </div>
  );
}
