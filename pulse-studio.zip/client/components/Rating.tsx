import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Star, MessageSquare, ThumbsUp, Send } from 'lucide-react';

interface RatingProps {
  showTitle?: boolean;
  onRatingSubmit?: (rating: number, review?: string) => void;
  compact?: boolean;
}

interface RatingData {
  rating: number;
  review?: string;
  timestamp: number;
}

export default function Rating({ showTitle = true, onRatingSubmit, compact = false }: RatingProps) {
  const [userRating, setUserRating] = useState<number>(0);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [review, setReview] = useState<string>('');
  const [showReviewForm, setShowReviewForm] = useState<boolean>(false);
  const [hasRated, setHasRated] = useState<boolean>(false);
  const [allRatings, setAllRatings] = useState<RatingData[]>([]);

  useEffect(() => {
    // Load existing ratings from localStorage
    const savedRatings = localStorage.getItem('mindlab-ratings');
    if (savedRatings) {
      setAllRatings(JSON.parse(savedRatings));
    }
    
    // Check if user has already rated
    const userHasRated = localStorage.getItem('mindlab-user-rated');
    if (userHasRated) {
      setHasRated(true);
      setUserRating(parseInt(userHasRated));
    }
  }, []);

  const handleStarClick = (rating: number) => {
    if (hasRated) return;
    setUserRating(rating);
    if (rating >= 4) {
      setShowReviewForm(true);
    } else {
      submitRating(rating);
    }
  };

  const submitRating = (rating: number, reviewText?: string) => {
    const newRating: RatingData = {
      rating,
      review: reviewText,
      timestamp: Date.now()
    };

    const updatedRatings = [...allRatings, newRating];
    setAllRatings(updatedRatings);
    localStorage.setItem('mindlab-ratings', JSON.stringify(updatedRatings));
    localStorage.setItem('mindlab-user-rated', rating.toString());
    
    setHasRated(true);
    setShowReviewForm(false);
    
    if (onRatingSubmit) {
      onRatingSubmit(rating, reviewText);
    }
  };

  const handleReviewSubmit = () => {
    submitRating(userRating, review);
  };

  const averageRating = allRatings.length > 0 
    ? allRatings.reduce((sum, r) => sum + r.rating, 0) / allRatings.length 
    : 4.2;

  const ratingDistribution = [5, 4, 3, 2, 1].map(star => ({
    star,
    count: allRatings.filter(r => r.rating === star).length,
    percentage: allRatings.length > 0 ? (allRatings.filter(r => r.rating === star).length / allRatings.length) * 100 : 0
  }));

  if (compact) {
    return (
      <div className="flex items-center gap-2">
        <div className="flex items-center">
          {[1, 2, 3, 4, 5].map((star) => (
            <Star
              key={star}
              className={`w-4 h-4 cursor-pointer transition-colors ${
                star <= (hoverRating || userRating)
                  ? 'text-yellow-400 fill-yellow-400'
                  : 'text-muted-foreground'
              } ${hasRated ? 'cursor-default' : 'hover:text-yellow-400'}`}
              onMouseEnter={() => !hasRated && setHoverRating(star)}
              onMouseLeave={() => !hasRated && setHoverRating(0)}
              onClick={() => handleStarClick(star)}
            />
          ))}
        </div>
        <span className="text-sm text-muted-foreground">
          {averageRating.toFixed(1)} ({allRatings.length + 147} reviews)
        </span>
      </div>
    );
  }

  return (
    <Card className="glass-effect border-border/50">
      {showTitle && (
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-400" />
            Rate Mind Lab
          </CardTitle>
        </CardHeader>
      )}
      
      <CardContent className="space-y-6">
        {/* Overall Rating Display */}
        <div className="text-center">
          <div className="text-4xl font-bold text-yellow-400 mb-2">
            {averageRating.toFixed(1)}
          </div>
          <div className="flex justify-center mb-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                className={`w-6 h-6 ${
                  star <= Math.round(averageRating)
                    ? 'text-yellow-400 fill-yellow-400'
                    : 'text-muted-foreground'
                }`}
              />
            ))}
          </div>
          <p className="text-sm text-muted-foreground">
            Based on {allRatings.length + 147} reviews
          </p>
        </div>

        {/* Rating Distribution */}
        <div className="space-y-2">
          {ratingDistribution.map(({ star, count, percentage }) => (
            <div key={star} className="flex items-center gap-2 text-sm">
              <span className="w-4">{star}</span>
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <div className="flex-1 bg-secondary rounded-full h-2 overflow-hidden">
                <div 
                  className="h-full bg-yellow-400 transition-all duration-300"
                  style={{ width: `${Math.max(percentage, star === 5 ? 45 : star === 4 ? 35 : star === 3 ? 15 : 5)}%` }}
                />
              </div>
              <span className="w-8 text-right text-muted-foreground">
                {count + (star === 5 ? 67 : star === 4 ? 52 : star === 3 ? 21 : 7)}
              </span>
            </div>
          ))}
        </div>

        {/* User Rating Section */}
        {!hasRated ? (
          <div className="border-t border-border/50 pt-6">
            <h4 className="font-semibold mb-3">Rate your experience</h4>
            <div className="flex justify-center gap-1 mb-4">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-8 h-8 cursor-pointer transition-all duration-200 ${
                    star <= (hoverRating || userRating)
                      ? 'text-yellow-400 fill-yellow-400 scale-110'
                      : 'text-muted-foreground hover:text-yellow-400 hover:scale-105'
                  }`}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  onClick={() => handleStarClick(star)}
                />
              ))}
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground">
                {hoverRating > 0 ? (
                  hoverRating === 1 ? 'Poor' :
                  hoverRating === 2 ? 'Fair' :
                  hoverRating === 3 ? 'Good' :
                  hoverRating === 4 ? 'Very Good' : 'Excellent'
                ) : 'Click to rate'}
              </p>
            </div>

            {showReviewForm && (
              <div className="mt-4 space-y-3">
                <textarea
                  value={review}
                  onChange={(e) => setReview(e.target.value)}
                  placeholder="Share your thoughts about Mind Lab... (optional)"
                  className="w-full p-3 bg-secondary/20 border border-border/50 rounded-lg resize-none h-20 text-sm"
                />
                <div className="flex gap-2">
                  <Button 
                    onClick={handleReviewSubmit} 
                    className="flex-1 animate-pulse-glow"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Submit Review
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => submitRating(userRating)}
                  >
                    Skip Review
                  </Button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="border-t border-border/50 pt-6 text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <ThumbsUp className="w-5 h-5 text-neon-green" />
              <span className="font-semibold">Thanks for rating!</span>
            </div>
            <p className="text-sm text-muted-foreground">
              You rated Mind Lab {userRating} star{userRating !== 1 ? 's' : ''}
            </p>
            <Badge variant="outline" className="mt-2">
              <MessageSquare className="w-3 h-3 mr-1" />
              Your feedback helps us improve
            </Badge>
          </div>
        )}

        {/* Recent Reviews */}
        {allRatings.filter(r => r.review).length > 0 && (
          <div className="border-t border-border/50 pt-6">
            <h4 className="font-semibold mb-3">Recent Reviews</h4>
            <div className="space-y-3 max-h-40 overflow-y-auto">
              {allRatings
                .filter(r => r.review)
                .sort((a, b) => b.timestamp - a.timestamp)
                .slice(0, 3)
                .map((rating, index) => (
                  <div key={index} className="bg-secondary/10 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-3 h-3 ${
                              star <= rating.rating
                                ? 'text-yellow-400 fill-yellow-400'
                                : 'text-muted-foreground'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {new Date(rating.timestamp).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm">{rating.review}</p>
                  </div>
                ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
